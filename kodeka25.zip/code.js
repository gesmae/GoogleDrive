var strRemoteDB = "http://kodeka.no-ip.info/ajax_post.php";
var gstrRemotedata;
var DB;
var intComercial;
var sqlList;
var dbrecords;
var dbauxrecordsonshow;
var currentrowppal;
var strEstadoPrincipal = "Clientes";
var txtNombreCliente;
var txtcodigo;
var txtNombreCliente;
var arraylista = createMultiDimArray('');

function sbCargaUnArticulo(tx) {
    if (strEstadoPrincipal == "Articulos") {
        strEstadoPrincipal = "Articulos";
        strArticuloActual = "";
        List1.deleteItem("all");
        DB.transaction(ObtenerUnArticulo(tx), errorCB);
        sbCargaArticulo();
    }
}

function resultcarga_panel(tx, results) {
    var straux;
    dbrecords = results;

    i = 0;
    nsbDOMAttr(panelDatos, 'style.display', "block");
    nsbDOMAttr(panelDatos, 'style.left', "40%");
    nsbDOMAttr(panelDatos, 'style.width', "50%");
    nsbDOMAttr(panelDatos, 'style.height', "90%");



    listDatos.deleteItem("all");
    //JavaScript
    //    JavaScript
    // $("#listDatos").empty()
    // End JavaScript
    //End JavaScript
    blnAbiertoPanel = true;
    nsbDOMAttr(panelDatos, 'style.top', "90");
    if (strEstadoPrincipal == "Clientes") {
        txtNombreCliente = results.rows.item(i)["NOMBRE"];
        txtcodigo = results.rows.item(i)["CODIGOCLIE"];
        strTarifaClienteActual = results.rows.item(i)["TARIFA"];
        HeaderBar1.value = txtcodigo + " " + txtNombreCliente;
        listDatos.addItem("<small>Tlf: " + results.rows.item(i)["TELEFONO"] + " / " + results.rows.item(i)["MOVIL"] + "/<small>", "", 1);
        listDatos.addItem("<small>Dirección " + results.rows.item(i)["DIRECCION"] + "/<small>", "", 2);
        listDatos.addItem("Mañana: " + results.rows.item(i)["HORARIOMA_"], "", 3);
        listDatos.addItem("Tarde: " + results.rows.item(i)["HORARIOTAR"], "", 4);
        listDatos.addItem("Noche: " + results.rows.item(i)["HORARIOCIE"], "", 5);
        listDatos.addItem("Tarifa: " + results.rows.item(i)["TARIFA"], "", 6);
        btnCobros.show();
        btnnuevoalbaran.show();
        btnEditarlbaran.hide();
        btnnuevoalbaran2.show();
        btnnuevoalbaran1.show();
        tipoalbaran = "Nuevo Albaran";
    } else if (strEstadoPrincipal == "Artículos") {
        HeaderBar1.value = results.rows.item(i)["CODIGOARTI"] + " " + results.rows.item(i)["DESCRIPCIO"];

        listDatos.addItem("Unidades Caja: " + results.rows.item(i)["BULTOS"], "", 1);
        listDatos.addItem("Tarifas: ", "", 2);
        for (i = 0; i <= results.rows.length - 1; i++) {
            if (results.rows.item(i)["mitarifa"] != "null") {
                listDatos.addItem(_vbsString(10 - Len(results.rows.item(i)["mitarifa"]), " ") + results.rows.item(i)["mitarifa"] + " " + results.rows.item(i)["miprecio"], "", i + 3);
            }
        }
        btnCobros.hide();
        btnnuevoalbaran.hide();
        btnEditarlbaran.hide();
        btnnuevoalbaran2.hide();
        btnnuevoalbaran1.hide();
    } else if (strEstadoPrincipal == "Albaranes") {


        HeaderBar1.value = "Albaran " + txtcodigo + " " + results.rows.item(i)["NOMBRE"];
        for (i = 0; i <= results.rows.length - 1; i++) {
            listDatos.addItem(results.rows.item(i)["UNIDADES"] + " " + results.rows.item(i)["DESCRIPCIO"], "", i);
        }
        btnCobros.hide();
        btnnuevoalbaran.hide();
        btnnuevoalbaran2.hide();
        btnnuevoalbaran1.hide();
        btnEditarlbaran.show();
    }
    listDatos.refresh();
}


function resultaalbaranesprincipal(transaction, results) {
    // Called On completion of Sql command in Function btnRead_onclick
    dbrecords = results;

    var j;
    var o;
    //'  List1.deleteItem("all")
    var datos_lista = "";

    var dato;
    j = 0;

    if (dbrecords.rows.length == 0) {
        NSB.MsgBox("No hay albaranes");
        return;
    }
    arraylista = createMultiDimArray(dbrecords.rows.length);
    for (i = 0; i <= dbrecords.rows.length - 1; i++) {
        impte = FormatNumber(dbrecords.rows.item(i)["IMPORTE"], 2, 8);
        dato = _vbsString(10 - Len(dbrecords.rows.item(i)["CALBARAN"]), "0") + " <yellow>Serie</yellow> " + dbrecords.rows.item(i)["Serie"] + " <span style='color:#E5F0EF'> " + dbrecords.rows.item(i)["Importe"] + "</span> " + dbrecords.rows.item(i)["NOMBRE"];
        dato = "<li><a data-role='button'> " + dbrecords.rows.item(i)["CALBARAN"] + " <span style='color:##FFBF00'>" + dbrecords.rows.item(i)["IMPORTE"] + "€ </SPAN> <span style='color:#ACFA58'>" + dbrecords.rows.item(i)["NOMBRE"] + "</span> <span Class='ui-li-count'> " + dbrecords.rows.item(i)["SERIE"] + "</span> </a></li>";
        dato = dbrecords.rows.item(i)["CALBARAN"] + " <span style='color:#F7F781'>" + dbrecords.rows.item(i)["SERIE"] + " </span><span style='color:#FFBF00'>  " + dbrecords.rows.item(i)["IMPORTE"] + "€ </span><span style='color:#80FF00'>  " + dbrecords.rows.item(i)["CAPTURA"] + " Lineas </span><span style='color:#CEF6F5'>" + dbrecords.rows.item(i)["NOMBRE"] + "</span>";
        o = _jsCint(dbrecords.rows.item(i)["CALBARAN"]);
        List1.addItem(dato, "", i);
        // List1.addItem(dato )
        arraylista[i] = o;
        // MsgBox "" & o & "   " & i
    }

    //y =Int( window.innerHeight * .77)
    // List1.style.height = y + "px"
    //List1.style.left = "0px"

    //List1.style.width = window.innerWidth  + "px"




    //List2.style.height = y + "px"
    nsbDOMAttr(List1_scroller, 'style.height', y + "px");
    List1.refresh();


}









function resultclientes(transaction, results) {
    // Called On completion of Sql command in Function btnRead_onclick

    dbrecords = results;
    var j;
    //'  List1.deleteItem("all")
    var datos_lista = "";
    var dblpendiente;
    var codigo, name;
    var dato;
    j = 0;

    arraylista = createMultiDimArray(dbrecords.rows.length);
    for (i = 0; i <= dbrecords.rows.length - 1; i++) {

        codigo = dbrecords.rows.item(i)["CODIGOCLIE"];
        name = dbrecords.rows.item(i)["NOMBRE"];
        dblpendiente = dbrecords.rows.item(i)["pte"];
        if (dblpendiente == null) {
            dblpendiente = 0;
        }

        if (dblpendiente != 0) {

            List1.addItem("<span style='color:#F7F781'>" + codigo + "<span style='color:##F78181'>  " + name + "</span> </span><span style='color:#80FF00'>  " + FormatNumber(dblpendiente, 2) + "€ </span>", "", i);

        } else {

            List1.addItem("<span style='color:#F7F781'>" + codigo + "</span> " + name, "", i);
            //List1.children[i].style.color="red"
        }
        arraylista[i] = codigo;
    }

    // y =Int( window.innerHeight * .77)
    //  List1.style.left = "0px"

    // List1.style.width = window.innerWidth  + "px"




    //List1.style.height = y + "px"
    nsbDOMAttr(List1_scroller, 'style.height', y + "px");
    List1.refresh();


}


function resultarticulos(transaction, results) {

    dbrecords = results;

    //'  List1.deleteItem("all")
    var datos_lista = "";
    var dblpendiente;
    var codigo, name;
    var dato;
    arraylista = createMultiDimArray(dbrecords.rows.length);
    for (i = 0; i <= dbrecords.rows.length - 1; i++) {


        codigo = dbrecords.rows.item(i)["CODIGOARTI"];
        //name=dbrecords.rows.item(i)["DESCRIPCIO"]




        //Sql[i]=codigo & " " & name

        List1.addItem("<span style='color:#F7F781'>" + codigo + "</span> " + dbrecords.rows.item(i)["DESCRIPCIO"]);
        //MsgBox i  & " / " & dato
        arraylista[i] = codigo;
    }

    List1.show();
    //  List1.Height=800 
    // y =Int( window.innerHeight * .77)

    //List1.style.left = "0px"

    //List1.style.width = window.innerWidth  + "px"




    nsbDOMAttr(List1_scroller, 'style.height', y + "px");
    List1.refresh();



}


function resultarifas(transaction, results) {
    // Called On completion of Sql command in Function btnRead_onclick
    dbrecords = results;

    var valor;

    var K;
    grdtarifas.addRows(dbrecords.rows.length);
    for (K = 0; K <= dbrecords.rows.length - 1; K++) {

        valor = dbrecords.rows.item(K)["codigotari"] + "€";
        //'      grdtarifas.setValue (K, 0, valor)
        valor = dbrecords.rows.item(K)["precio"] + "€";
        //'   grdtarifas.setValue(K, 1, valor  )

    }


}

function resultcargaalbaranedicion(transaction, results) {
    var K;
    dbrecords = results;

    if (dbrecords.rows.length == 0) {
        NSB.MsgBox("Error albaran no encontrado");
        return;
    }
    1;

    // valor=dbrecords.rows.item(K)["CALBARAN"] 

    txtcodigo = dbrecords.rows.item(0)["CCLIENTE"];
    txtNombreCliente = dbrecords.rows.item(0)["NOMBRE"];
    x = txtcodigo;
    y = txtNombreCliente;
    frmAlbaran.txtnombreclientealbaran = txtNombreCliente;
    frmAlbaran.txtTarifaCliente = txtTarifaCliente.value;
    frmAlbaran.txtcodigoclientealbaran = x;
    txtcodigo = dbrecords.rows.item(0)[""];
    frmAlbaran.txtObservaciones = dbrecords.rows.item(0)["OBS"];
    frmAlbaran.txtNumeroAlbaran = dbrecords.rows.item(0)["CALBARAN"];
    //serie==dbrecords.rows.item(0)["SERIE"]
    frmAlbaran.txtSerie = dbrecords.rows.item(0)["SERIE"];
    if (dbrecords.rows.item(0)["SERIE"] == "55") {
        filtrotarifa = " and  codigotari=55 ";
        frmAlbaran.txtTarifaCliente = "55";
    } else {
        filtrotarifa = " ";
        frmAlbaran.txtTarifaCliente = txtTarifaCliente.value;
    }

    sqlList = [];
    for (K = 0; K <= dbrecords.rows.length - 1; K++) {
        sqlList[K] = ["Update FRECUENC SET PPEDIDO=" + dbrecords.rows.item(K)["UNIDADES"] + ", pprecio=" + dbrecords.rows.item(K)["PRECIO"] + " , PTARIFA=" + dbrecords.rows.item(K)["TARIFA"] + " , PDTO=" + dbrecords.rows.item(K)["DCTO"] + " where id=" + dbrecords.rows.item(K)["ID"]];



    }
    Sql(DB, sqlList);

    //If serie="" Or serir  Then Exit Sub


    // frmAlbaran.btnHistorico.hide()
    strEstadoAnadir = "Pedido";

    ChangeForm(frmAlbaran);

}

btnbuscar.onclick = function() {
    txtbusquedadescripcion.blur();
    txtbusquedacodigo.blur();
    //SetTimeout(,1000)
    if (txtbusquedacodigo.value == "" && txtbusquedadescripcion.value == "") {

        return;
    }





    // If txtbusquedacodigo.value="" And txtbusquedadescripcion.value="" Then Exit Sub
    switch (true) {
        case ((strEstadoPrincipal) == "Clientes"):
            // MsgBox "1"
            sbcargaclientes();
            //    MsgBox "2"
            break;
        case ((strEstadoPrincipal) == "Artículos"):
            //  btncobros.disabled=True

            sbcargaarticulosPrincipal();
    }
    List1.width = "100%";
    List1.refresh();
    $('#List1').trigger('updatelayout'); //these don't collapse my space

};


function sbcheckdatabase() {
    sqlList = [];
    sqlList[0] = "SELECT name FROM sqlite_master WHERE type='table' AND name='table_name';";

    Sql(DB, sqlList);
    if (dbrecords.rows.length != 0) {
        NSB.MsgBox("Base de datos erronea. Se va a proceder a su carga");
        sbInicializar();
    }
}






function sbcargaclientes() {

    var straux;
    var strOrigen;
    var strAuxCodigo;
    if (txtbusquedacodigo.value == "" && txtbusquedadescripcion.value == "") {

        return;
    }

    strOrigen = txtbusquedadescripcion.value;


    straux = "";
    //$("#List1").empty()
    List1.deleteItem("all");
    straux = strOrigen.indexOf(' ');

    var n = strOrigen.split(' ');
    straux = ' NOMBRE like "%' + n[0] + '%" '
    strAuxCodigo = ' CODIGOCLIE like "%' + n[0] + '%" '
    for (i = 1; i < n.length; i++) {
        straux = straux + ' and NOMBRE like "%' + n[i] + '%"'
        strAuxCodigo = strAuxCodigo + ' and CODIGOCLIE like "%' + n[i] + '%"'
    }

    sqlList = [];

    sqlList[0] = ["Select CODIGOCLIE, NOMBRE, SUM(COBROS.IMPORTE-COBROS.COBRADO - COBROS.COBROS) AS pte  from CLIENTE  Left Join COBROS On cliente.codigoclie=cobros.CCLIENTE GROUP BY CODIGOCLIE, NOMBRE HAVING " + straux + " or " + strAuxCodigo + " ORDER BY NOMBRE limit 50;", resultclientes];




    NSB.WaitCursor(true);
    Sql(DB, sqlList);
    // MsgBox "" &  UBound(DBRecords)-1
    NSB.WaitCursor(false);

}


function sbcargaarticulosPrincipal() {

    var straux;
    var strOrigen;
    var strAuxCodigo;
    strOrigen = txtbusquedadescripcion.value;
    // JavaScript
    //$("#List1").empty()
    //End JavaScript
    List1.deleteItem("All");
    //MsgBox  txtbusquedacodigo.value
    if (txtbusquedacodigo.value == "" && txtbusquedadescripcion.value == "") {

        return;
    }
    strAuxCodigo = "  articulo.CODIGOARTI like '" + txtbusquedacodigo.value + "%' ";
    if (Len(txtbusquedadescripcion.value) == 99999 && Math.floor(txtbusquedadescripcion.value) > 0) {

        straux = "  articulo.CODIGOARTI like '" + strOrigen + "%'";
        strAuxCodigo = "  articulo.CODIGOARTI like '" + strOrigen + "%'";
    } else {
        straux = strOrigen.indexOf(' ');

        var n = strOrigen.split(' ');
        straux = ' descripcio like "%' + n[0] + '%" '

        for (i = 1; i < n.length; i++) {
            straux = straux + ' and DESCRIPCIO like "%' + n[i] + '%"'

        }

        strAuxCodigo = " articulo.CODIGOARTI like '" + txtbusquedacodigo.value + "%' ";
        if (txtbusquedadescripcion.value == "") {
            straux = strAuxCodigo;
        }
        if (txtbusquedacodigo.value == "") {
            strAuxCodigo = "";
        }
        // strAuxCodigo=strAuxCodigo + ' and articulo.CODIGOARTI like "%' + n[i] + '%"'
    }
    sqlList = [];
    sqlList[0] = ["Select articulo.CODIGOarti, descripcio from articulo   WHERE " + straux + " ORDER BY descripcio, articulo.codigoarti LIMIT 500;", resultarticulos];



    NSB.WaitCursor(true);
    Sql(DB, sqlList);
    // MsgBox "" &  UBound(DBRecords)-1
    NSB.WaitCursor(false);

}

function sbcargaalbaranessprincipal() {


    List1.deleteItem("all");
    //  MsgBox "1"
    sqlList = [];

    sqlList[0] = ["SELECT  ALBARAN.*, CLIENTE.NOMBRE from ALBARAN INNER Join CLIENTE On ALBARAN.CCLIENTE=CLIENTE.CODIGOCLIE ORDER BY CALBARAN, CALBARAN   limit 100;", resultaalbaranesprincipal];

    Sql(DB, sqlList);


}


function sbcargaalbaranes() {
    if (DB == 0) {
        sbInicializar();
    }

    List1.deleteItem("all");

    sqlList = [];

    sqlList[0] = ["Select distinct cliente.nombre, cliente.codigoclie from  frecuenc Left Join cliente On frecuenc.codigoclie=cliente.codigoclie where ppedido <>0  order by   cliente.nombre limit 200;", resultalbaran];

    Sql(DB, sqlList);


}


function sbcargaTarifa(codigoarti) {
    var j;

    for (j = 0; j <= 7; j++) {
        // grdtarifas.getRowCount()>0
        //'   grdtarifas.deleteRows(1)  
    }
    //   MsgBox "ya"
    sqlList = [];
    //  sqlList[0]=["Select articulo.codigoarti, DESCRIPCIO , codigotari, atarifas.precio as miprecio from articulo Left Join atarifas On articulo.codigoarti=atarifas.codigoarti WHERE DESCRIPCIO <>'' and DESCRIPCIO<>'null' and DESCRIPCIO LIKE '%"  & txtbusquedadescripcion.value & "%' and articulo.codigoARTI like '%" & & txtbusquedacodigo.value & "%'  ORDER BY DESCRIPCIO   limit 100;", resultarticulos]
    sqlList[0] = ["SELECT  codigoarti, codigotari, precio from ATARIFAS WHERE codigoARTI= '" + codigoarti + "'  ORDER BY codigotari  ;", resultarifas];



    Sql(DB, sqlList);


}

function sbCargaClienteActual(x) {


    sqlList = [];
    // MsgBox "" & dbrecords.rows.item(CInt(x))["CODIGOCLIE"]
    sqlList[0] = ["Select Cliente.* , SUM(COBROS.IMPORTE-COBROS.COBRADO) AS pte  from CLIENTE  Left Join COBROS On cliente.CODIGOCLIE=cobros.CCLIENTE where CODIGOCLIE='" + txtcodigo + "' GROUP BY CODIGOCLIE, NOMBRE  ORDER BY NOMBRE;", resultcarga_panel];

    dbauxrecords = [];
    NSB.WaitCursor(true);
    Sql(DB, sqlList);
    NSB.WaitCursor(false);
}


function sbCargaArticuloActual(x) {


    sqlList = [];
    // MsgBox "" & dbrecords.rows.item(CInt(x))["CODIGOARTI"]
    sqlList[0] = ["SELECT articulo.*, atarifas.codigotari as mitarifa, atarifas.precio as miprecio  from articulo Left Join atarifas On articulo.codigoarti=atarifas.codigoarti  WHERE  articulo.CODIGOARTI = '" + x + "' ORDER BY Codigotari ;", resultcarga_panel];
    //  sqlList[0]=["Select articulo.CODIGOarti, bultos, descripcio, codigotari, atarifas.precio from articulo  Left Join atarifas On articulo.CODIGOarti=atarifas.CODIGOarti WHERE " & strAux & " Or " & strAuxCodigo &  " ORDER BY descripcio, articulo.codigoarti, Codigotari  ;", resultarticulos]

    dbauxrecords = [];
    NSB.WaitCursor(true);
    Sql(DB, sqlList);

}


function sbCargaAlbaranActual(z) {
    var x;
    var y;
    var serie;




    sqlList = [];
    sqlList[0] = ["Select DISTINCT  ALBARANL.*, albaran.ccliente, albaran.IMPORTE,  CLIENTE.NOMBRE, ARTICULO.DESCRIPCIO, ALBARANL.UNIDADES from ALBARAN left join albaranl on albaranl.calbaran=albaran.calbaran left join CLIENTE on CLIENTE.CODIGOCLIE=albaran.CCLIENTE left join ARTICULO ON ALBARANL.CODIGOARTI=ARTICULO.CODIGOARTI WHERE ALBARAN.CALBARAN=" + z + " order by ARTICULO.DESCRIPCIO;", resultcarga_panel];
    Sql(DB, sqlList);


}




function sbCargaAlbaranActualEditar(z) {
    var x;
    var y;
    var serie;


    frmAlbaran.txtcodigoclientealbaran = x;


    frmAlbaran.txtnombreclientealbaran = y;
    frmAlbaran.txtTarifaCliente = txtTarifaCliente.value;



    frmAlbaran.txtNumeroAlbaran = z;
    blnNuevoAlbaran = 0;
    strEstadoAnadir = "Pedido";

    sqlList = [];
    sqlList[0] = ["Select ALBARANL.*, albaran.obs, albaran.ccliente, albaran.serie,  CLIENTE.NOMBRE, ARTICULO.DESCRIPCIO, ALBARANL.UNIDADES from ALBARAN left join albaranl on albaranl.calbaran=albaran.calbaran left join CLIENTE on CLIENTE.CODIGOCLIE=albaran.CCLIENTE left join ARTICULO ON ALBARANL.CODIGOARTI=ARTICULO.CODIGOARTI WHERE ALBARAN.CALBARAN=" + z + ";", resultcargaalbaranedicion];
    Sql(DB, sqlList);


}








function fnNuevoAlbaran(serie) {
    var x;
    var y;

    var misql;
    nsbDOMAttr(panelDatos, 'style.display', "none");
    blnAbiertoPanel = false;

    misql = "Update FRECUENC set PPEDIDO=0,";
    misql = misql + " PDTO=0, ";
    misql = misql + " PTARIFA=0, ";
    misql = misql + " PPRECIO=0";
    sqlList = [];
    sqlList[0] = misql;
    Sql(DB, sqlList);
    x = txtcodigo;
    y = txtNombreCliente;

    frmAlbaran.txtcodigoclientealbaran = x;

    frmAlbaran.txtObservaciones = "";
    frmAlbaran.txtnombreclientealbaran = y;
    if (serie == "55") {
        filtrotarifa = " and  codigotari=55 ";
        frmAlbaran.txtTarifaCliente = "55";

    } else {
        filtrotarifa = " ";
        frmAlbaran.txtTarifaCliente = txtTarifaCliente.value;
    }
    strEstadoAnadir = "Historico";
    if (tipoalbaran == "Nuevo Albaran") {

        frmAlbaran.txtNumeroAlbaran = _jsCint(localStorage.intUltimoAlbaran) + 1;
        blnNuevoAlbaran = 1;
        // serie=InputBox("Serie del Albaran nº " &  frmAlbaran.txtNumeroAlbaran  ,"01","01")
        //If serie="" Or serir  Then Exit Sub
        if (serie == "ca") {
            serie = "CA";
        }

        if (serie == "55" || serie == "01" || serie == "CA") {
            frmAlbaran.txtSerie = serie;
        } else {
            return;
        }
        if (serie == "55") {
            strTarifaClienteActual = "55";
        }
    } else {

    }

    strEstadoAnadir = "Historico";

    ChangeForm(frmAlbaran);



}

function sbeditaralbaran() {
    var x;
    var y;

    var misql;
    nsbDOMAttr(panelDatos, 'style.display', "none");
    blnAbiertoPanel = false;
    List1.deleteItem("all");
    sbCargaAlbaranActualEditar(txtcodigo);


}




FooterBar1.onclick = function(choice) {
    var straux;





    switch (true) {

        case ((choice) == "Clientes"):
            if (strEstadoPrincipal == "Clientes") {
                return;
            };
            if (blnAbiertoPanel) {
                nsbDOMAttr(panelDatos, 'style.display', "none");
                blnAbiertoPanel = false;
            }

            List1.deleteItem("all");
            strEstadoPrincipal = "Clientes";
            txtbusquedacodigo.value = "";
            txtbusquedacodigo.Visible = false;

            currentrowppal = -1;
            //List1.top=253
            //  List1.height=350
            frmCobros.txtcodigoclientecobro = "";


            frmCobros.txtnombreclientecobro = "";


            btnbuscar.show();

            //   txtbusquedadescripcion.show()




            sbcargaclientes();



            break;
        case ((choice) == "Artículos"):
            if (strEstadoPrincipal == "Artículos") {
                return;
            };

            if (blnAbiertoPanel) {
                nsbDOMAttr(panelDatos, 'style.display', "none");
                blnAbiertoPanel = false;
            }

            List1.deleteItem("all");
            currentrowppal = -1;
            //  List1.top=235

            txtbusquedacodigo.value = "";
            txtbusquedacodigo.Visible = true;
            btnbuscar.show();


            //  txtbusquedadescripcion.show()
            txtbusquedadescripcion.value = "";
            txtNombreCliente = "";
            xttcodigo = "";



            strEstadoPrincipal = "Artículos";


            sbcargaarticulosPrincipal();




            break;
        case ((choice) == "Albaranes"):
            if (strEstadoPrincipal == "Albaranes") {
                return;
            }
            if (blnAbiertoPanel) {
                nsbDOMAttr(panelDatos, 'style.display', "none");
                blnAbiertoPanel = false;
            }

            frmCobros.txtcodigoclientecobro = "";


            frmCobros.txtnombreclientecobro = "";

            List1.deleteItem("all");
            currentrowppal = -1;
            strEstadoPrincipal = "Albaranes";
            tipoalbaran = "Editar Albaran";
            btnbuscar.hide();


            //  txtbusquedadescripcion.hide()

            straux = txtcodigo;



            sbcargaalbaranessprincipal();
            return;

            break;
        case ((choice) == "Cobros"):

            var x;

            var y;
            var serie;
            if (strEstadoPrincipal == "Cobros") {
                return;
            }
            if (blnAbiertoPanel) {
                nsbDOMAttr(panelDatos, 'style.display', "none");
                blnAbiertoPanel = false;
            }

            List1.deleteItem("all");
            strEstadoPrincipal = "Cobros";
            blnResumenCobros = 1;
            currentrowppal = -1;

            x = "";

            frmCobros.txtcodigoclientecobro = "";


            frmCobros.txtnombreclientecobro = "";

            blnResumenCobros = 1;

            ChangeForm(frmCobros);



            break;
        case ((choice) == "Enviar"):

            break;
        case ((choice) == "Conf."):
            NSB.MsgBox(yesNoDone_Carga, "¿Desea realizar la carga completa de la máquina? Los albaranes no traspasados se perderan.", 4 + 32);




    }

};

function yesNoDone_Carga(result) {
    NSB.MsgBox("" + result);
    if (resukt == 1) {
        sbInicializar();
    }

}

frmPrincipal.onshow = function() {
    document.body.style.backgroundColor = "gray";
    nsbDOMAttr(frmPrincipal, 'style.width', "100%");
    nsbDOMAttr(frmPrincipal, 'style.height', "100%");
    if (Len(localStorage.comercial) == 1) {

        strComercial = "0" + localStorage.comercial;
    } else {
        strComercial = localStorage.comercial;

    }

    blnResumenCobros = 0;




    if (strEstadoPrincipal == "Albaranes") {


        frmCobros.txtcodigoclientecobro = "";


        frmCobros.txtnombreclientecobro = "";

        List1.deleteItem("all");
        currentrowppal = -1;

        tipoalbaran = "Editar Albaran";
        btnbuscar.hide();


        //  txtbusquedadescripcion.hide()

        straux = txtcodigo;



        sbcargaalbaranessprincipal();

    }

};




function CambioLista(milista) {

    straux = milista;
    switch (true) {


        case ((strEstadoPrincipal) == "Clientes"):
            strEstadoPrincipal = "Clientes";
            straux = fnRecuperarElementoLista(List1, straux, 0);
            txtcodigo = _vbsString(4 - Len(straux), "0") + straux;
            txtNombreCliente = fnRecuperarElementoLista(List1, milista, 1);
            sbCargaClienteActual(txtcodigo);

            break;
        case ((strEstadoPrincipal) == "Artículos"):


            txtcodigo = fnRecuperarElementoLista(List1, straux, 0);
            sbCargaArticuloActual(txtcodigo);


            break;
        case ((strEstadoPrincipal) == "Albaranes"):

            if (txtcodigo == fnRecuperarElementoLista(List1, straux, 0) && txtNombreCliente == fnRecuperarElementoLista(List1, straux, 1)) {
                return;
            }


            txtcodigo = fnRecuperarElementoLista(List1, straux, 0);
            txtNombreCliente = fnRecuperarElementoLista(List1, straux, 1);



    }
    sbActualizarLista(milista);
}






function resulcarga_envioCompleto(transaction, results) {
    dbrecords = results;

    var albaranactual;
    var ALBARAN;
    var ALBARANL;
    var linea;
    var strObservacionesEnvio;
    //'  List1.deleteItem("all")
    var datos_lista = "";
    var straux;
    var dato;
    j = 0;
    var intEnvioActual;
    ALBARAN = "";
    ALBARANL = "";
    strObservacionesEnvio = "";
    albaranactual = "weñflkwelfkj";
    linea = 1;
    if (dbrecords.rows.length == 0) {
        NSB.MsgBox("No hay albaranes");
        return;
    }

    if (localStorage.intUltimoenvio > 9) {
        intEnvioActual = localStorage.intUltimoenvio;
    } else {
        intEnvioActual = 0 + localStorage.intUltimoenvio;
    }
    for (i = 0; i <= dbrecords.rows.length - 1; i++) {
        if (dbrecords.rows.item(i)["CALBARAN"] != albaranactual) {
            straux = CStr(dbrecords.rows.item(i)["IMPORTE"]);

            straux = Replace(straux, ".", ",");
            strObservacionesEnvio = dbrecords.rows.item(i)["OBS"];
            strObservacionesEnvio = Replace(strObservacionesEnvio, Chr(10), " ");
            strObservacionesEnvio = Replace(strObservacionesEnvio, Chr(13), " ");
            strObservacionesEnvio = "CLIENTE: " + dbrecords.rows.item(i)["CCLIENTE"] + " " + strObservacionesEnvio;

            ALBARAN = ALBARAN + "" + '"' + "" + dbrecords.rows.item(i)["CALBARAN"] + ";" + miFormatoFecha(dbrecords.rows.item(i)["FECHA"]) + ";" + miFormatoFecha(dbrecords.rows.item(i)["FECHA"]) + ";" + dbrecords.rows.item(i)["CCLIENTE"] + ";" + dbrecords.rows.item(i)["OBS"] + ";" + straux + ";;" + dbrecords.rows.item(i)["SERIE"] + ";" + '"' + "" + Chr(13) + Chr(10);
            albaranactual = dbrecords.rows.item(i)["CALBARAN"];
            linea = 1;
        }
        straux = CStr(dbrecords.rows.item(i)["PRECIO"]);

        straux = Replace(straux, ".", ",");
        ALBARANL = ALBARANL + "" + '"' + "" + dbrecords.rows.item(i)["CALBARAN"] + ";" + linea + ";" + dbrecords.rows.item(i)["CODIGOARTI"] + ";" + dbrecords.rows.item(i)["UNIDADES"] + ";" + straux + ";" + dbrecords.rows.item(i)["DCTO"] + ";;;" + dbrecords.rows.item(i)["TARIFA"] + ";" + '"' + "" + Chr(13) + Chr(10);
        linea = linea + 1;
    }


    EmailText = ALBARAN;
    Url = "http://kodeka.no-ip.info/file.php/?EmailTo=" + "c:\\gesmae\\" + strComercial + localStorage.intUltimoenvio + "ALB.TXT";
    req = Ajax(Url, "POST", EmailText);
    //  req=Ajax(url,"POST","/no-cache?" & Date)
    if (req.status == 200) { //success
        //   MsgBox("Email enviado")
    } else { //failure
        NSB.MsgBox("Error enviando cabecera " + req.err);
    }
    EmailText = ALBARANL;
    Url = "http://kodeka.no-ip.info/file.php/?EmailTo=" + "c:\\gesmae\\" + strComercial + localStorage.intUltimoenvio + "ALBL.TXT";
    req = Ajax(Url, "POST", EmailText);
    //  req=Ajax(url,"POST","/no-cache?" & Date)
    if (req.status == 200) { //success
        sqlList = [];
        sqlList[0] = ["SELECT  COBROS.* from cobros WHERE cobros<>0  order by CCLIENTE, TIPO;", resulcarga_envioCobrosCompleto];
        Sql(DB, sqlList);
    } else { //failure
        NSB.MsgBox("Error enviando cabecera " + req.err);
    }
    localStorage.intUltimoenvio = _jsCint(localStorage.intUltimoenvio);
    if (localStorage.intUltimoenvio == 100) {
        localStorage.intUltimoenvio = 10;
    }


}

function resulcarga_envio(transaction, results) {
    dbrecords = results;

    var albaranactual;
    var ALBARAN;
    var ALBARANL;
    var linea;

    //'  List1.deleteItem("all")
    var datos_lista = "";
    var straux;
    var dato;
    j = 0;
    var strObservacionesEnvio;
    var intEnvioActual;
    ALBARAN = "";
    ALBARANL = "";
    strObservacionesEnvio = "";
    albaranactual = "weñflkwelfkj";
    linea = 1;
    if (dbrecords.rows.length == 0) {
        NSB.MsgBox("No hay albaranes");
        return;
    }

    if (localStorage.intUltimoenvio > 9) {
        intEnvioActual = localStorage.intUltimoenvio;
    } else {
        intEnvioActual = 0 + localStorage.intUltimoenvio;
    }
    for (i = 0; i <= dbrecords.rows.length - 1; i++) {
        if (dbrecords.rows.item(i)["CALBARAN"] != albaranactual) {
            straux = CStr(dbrecords.rows.item(i)["IMPORTE"]);
            strObservacionesEnvio = dbrecords.rows.item(i)["OBS"];
            strObservacionesEnvio = Replace(strObservacionesEnvio, Chr(10), " ");
            strObservacionesEnvio = Replace(strObservacionesEnvio, Chr(13), " ");
            strObservacionesEnvio = "CLIENTE: " + dbrecords.rows.item(i)["CCLIENTE"] + " " + strObservacionesEnvio;
            straux = Replace(straux, ".", ",");

            ALBARAN = ALBARAN + "" + '"' + "" + dbrecords.rows.item(i)["CALBARAN"] + ";" + miFormatoFecha(dbrecords.rows.item(i)["FECHA"]) + ";" + miFormatoFecha(dbrecords.rows.item(i)["FECHA"]) + ";" + dbrecords.rows.item(i)["CCLIENTE"] + ";" + strObservacionesEnvio + ";" + straux + ";;" + dbrecords.rows.item(i)["SERIE"] + ";" + '"' + "" + Chr(13) + Chr(10);
            albaranactual = dbrecords.rows.item(i)["CALBARAN"];
            linea = 1;
        }
        straux = CStr(dbrecords.rows.item(i)["PRECIO"]);

        straux = Replace(straux, ".", ",");
        ALBARANL = ALBARANL + "" + '"' + "" + dbrecords.rows.item(i)["CALBARAN"] + ";" + linea + ";" + dbrecords.rows.item(i)["CODIGOARTI"] + ";" + dbrecords.rows.item(i)["UNIDADES"] + ";" + straux + ";" + dbrecords.rows.item(i)["DCTO"] + ";;;" + dbrecords.rows.item(i)["TARIFA"] + ";" + '"' + "" + Chr(13) + Chr(10);
        linea = linea + 1;
    }


    EmailText = ALBARAN;
    Url = "http://kodeka.no-ip.info/file.php/?EmailTo=" + "c:\\gesmae\\" + strComercial + localStorage.intUltimoenvio + "ALB.TXT";
    req = Ajax(Url, "POST", EmailText);
    //  req=Ajax(url,"POST","/no-cache?" & Date)
    if (req.status == 200) { //success
        //   MsgBox("Email enviado")
    } else { //failure
        NSB.MsgBox("Error enviando cabecera " + req.err);
    }
    EmailText = ALBARANL;
    Url = "http://kodeka.no-ip.info/file.php/?EmailTo=" + "c:\\gesmae\\" + strComercial + localStorage.intUltimoenvio + "ALBL.TXT";
    req = Ajax(Url, "POST", EmailText);
    //  req=Ajax(url,"POST","/no-cache?" & Date)
    if (req.status == 200) { //success
        NSB.MsgBox("Albaranes Enviados, FICHERO:" + intEnvioActual);
    } else { //failure
        NSB.MsgBox("Error enviando cabecera " + req.err);
    }
    localStorage.intUltimoenvio = _jsCint(localStorage.intUltimoenvio) + 1;
    if (localStorage.intUltimoenvio == 100) {
        localStorage.intUltimoenvio = 10;
    }


}




List1.onclick = function(i) {
    // window.blur()
    if (TypeName(i) == "object") {
        return;
    }


    txtcodigo = arraylista[i];
    nsbDOMAttr(panelDatos, 'style.display', "none");

    if (strEstadoPrincipal == "Clientes") {
        sbCargaClienteActual(txtcodigo);
    }
    if (strEstadoPrincipal == "Artículos") {
        sbCargaArticuloActual(txtcodigo);
    }
    if (strEstadoPrincipal == "Albaranes") {

        sbCargaAlbaranActual(txtcodigo);
    }
};

function sbAbrirCobrosCliente() {

    var x;

    var y;
    var serie;


    x = txtcodigo;
    //   y=txtNombreCliente

    frmCobros.txtcodigoclientecobro = x;


    frmCobros.txtnombreclientecobro = txtNombreCliente;

    blnResumenCobros = 0;

    nsbDOMAttr(panelDatos, 'style.display', "none");
    blnAbiertoPanel = false;
    ChangeForm(frmCobros);


}

btnbuscar.onfocus = function() {
    this.blur();
};

function sbEliminarTablas() {
    //continue1= MsgBox ("¿Desea elimianr todos los datos? Debera cargar la máquina despues",1)
    //     If continue1=vbOK Then

    sqlList = [];
    sqlList[0] = [" DROP TABLE IF EXISTS  ALBARANL;"];
    //  MsgBox  sqlList[0]
    sqlList[1] = ["DROP TABLE IF EXISTS ALBARAN ;"];
    sqlList[2] = ["DROP TABLE IF EXISTS  ARTICULO;"];
    //  MsgBox  sqlList[0]
    sqlList[3] = ["DROP TABLE IF EXISTS CLIENTE ;"];
    sqlList[5] = ["DROP TABLE IF EXISTS ;"];
    //  MsgBox  sqlList[0]
    sqlList[4] = ["DROP TABLE IF EXISTS ATARIFAS ;"];
    sqlList[5] = ["DROP TABLE IF EXISTS  COBROS;"];
    //  MsgBox  sqlList[0]
    sqlList[6] = ["DROP TABLE IF EXISTS  COMISIONISTAS;"];

    //   MsgBox  sqlList[1]



    Sql(DB, sqlList);
    //        MsgBox  "Datos borrandose. Espere un minuto"
    //  End If   
}

txtbusquedadescripcion.onclick = function() {
    txtbusquedadescripcion.value = "";
};



Select2.onchange = function() {
    if (Select2.selectedIndex() == "2") {
        if (NSB.MsgBox("¿Desea enviar los pedidos?", 4 + 32) == 1) {
            //MsgBox Button3done,"Do you like this tour?", vbYesNo+vbQuestion, TITLE
            sqlList = [];
            sqlList[0] = ["Select DISTINCT  ALBARANL.*,  albaran.FECHA,  albaran.HORA,  albaran.OBS,  albaran.serie,albaran.CCLIENTE, albaran.IMPORTE,  CLIENTE.NOMBRE, ARTICULO.DESCRIPCIO, ALBARANL.UNIDADES from ALBARAN left join albaranl on albaranl.calbaran=albaran.calbaran left join CLIENTE on CLIENTE.CODIGOCLIE=albaran.CCLIENTE left join ARTICULO ON ALBARANL.CODIGOARTI=ARTICULO.CODIGOARTI WHERE ALBARAN.TRANSMITIDO=0 ORDER BY ALBARANL.CALBARAN, CLIENTE.CODIGOCLIE, ALBARANL.rowid;", resulcarga_envio];
            Sql(DB, sqlList);
        }




    }

    if (Select2.selectedIndex() == "3") {
        if (NSB.MsgBox("¿Desea enviar los cobros?", 4 + 32) == 1) {

            sqlList = [];
            sqlList[0] = ["SELECT  COBROS.* from cobros WHERE cobros<>0  order by CCLIENTE, TIPO;", resulcarga_envioCobros];
            Sql(DB, sqlList);
        }




    }
    if (Select2.selectedIndex() == "1") {
        if (NSB.MsgBox("¿Desea enviar pedidos y cobros?", 4 + 32) == 1) {
            sqlList = [];
            sqlList[0] = ["Select DISTINCT  ALBARANL.*,  albaran.FECHA,  albaran.HORA,  albaran.OBS,  albaran.serie,albaran.CCLIENTE, albaran.IMPORTE,  CLIENTE.NOMBRE, ARTICULO.DESCRIPCIO, ALBARANL.UNIDADES from ALBARAN left join albaranl on albaranl.calbaran=albaran.calbaran left join CLIENTE on CLIENTE.CODIGOCLIE=albaran.CCLIENTE left join ARTICULO ON ALBARANL.CODIGOARTI=ARTICULO.CODIGOARTI WHERE ALBARAN.TRANSMITIDO=0 ORDER BY ALBARANL.CALBARAN, ALBARANL.rowid;", resulcarga_envioCompleto];
            Sql(DB, sqlList);


        }

        Select2.setIndex(0);


    }

    if (Select2.selectedIndex() == "5") {
        if (NSB.MsgBox("¿Desea realizar la carga completa de la máquina? Los albaranes no traspasados se perderan.", 4 + 32) == 1) {

            ChequearCarga();

            sbInicializar();
        }

    }

    if (Select2.selectedIndex() == "4") {




        if (NSB.MsgBox("¿Desea eliminar los albaranes?", 4 + 32) == 1) {
            sqlList = [];
            sqlList[0] = [" delete  from  ALBARANL;"];
            //  MsgBox  sqlList[0]
            sqlList[1] = [" delete  from  ALBARAN;"];




            Sql(DB, sqlList);
            localStorage.intUltimoAlbaran = 0;

            NSB.MsgBox("Albaranes Eliminados");
        }
        List1.deleteItem("all");
        Select2.setIndex(0);
    }

    if (Select2.selectedIndex() == "6") {




        if (NSB.MsgBox("¿Desea consolidar los cobros?", 4 + 32) == 1) {
            sqlList = [];
            sqlList[0] = [" update COBROS SET COBRADO=COBRADO + COBROS WHERE COBROS<>0;"];
            //  MsgBox  sqlList[0]
            sqlList[1] = [" update COBROS SET COBROS=0 WHERE COBROS<>0;"];




            Sql(DB, sqlList);
            NSB.MsgBox("Cobros Consolidados");
        }
        Select2.setIndex(0);
    }
    if (Select2.selectedIndex() == "7") {
        var clave;
        clave = prompt("Introduzca codigo de cambio", "");
        if (clave == "1551") {
            intcomercial = prompt("Introduzca comercial", "");
            localStorage.comercial = intcomercial;

            localStorage.intUltimoAlbaran = 0;
            TextBox1.value = "V. 1.52 Comercial " + localStorage.comercial;
        }
    }

    Select2.setIndex(0);
};

function resulcarga_envioCobros(transaction, results) {
    dbrecords = results;

    var albaranactual;
    var ALBARAN;
    var ALBARANL;
    var linea;

    //'  List1.deleteItem("all")
    var datos_lista = "";
    var straux, strAuxCobrado;
    var dato;
    j = 0;
    var intEnvioActual;
    ALBARAN = "";
    ALBARANL = "";

    albaranactual = "weñflkwelfkj";
    linea = 1;
    if (dbrecords.rows.length == 0) {
        NSB.MsgBox("No hay cobros");
        return;
    }
    // albaranactual=dbrecords.rows.item(0)["CALBARAN"]
    if (localStorage.intUltimoenvio > 9) {
        intEnvioActual = localStorage.intUltimoenvio;
    } else {
        intEnvioActual = 0 + localStorage.intUltimoenvio;
    }
    for (i = 0; i <= dbrecords.rows.length - 1; i++) {

        straux = CStr(dbrecords.rows.item(i)["IMPORTE"]);

        straux = Replace(straux, ".", ",");
        strAuxCobrado = CStr(dbrecords.rows.item(i)["COBROS"]);
        strAuxCobrado = Replace(strAuxCobrado, ".", ",");
        ALBARAN = ALBARAN + "" + '"' + "" + dbrecords.rows.item(i)["EJERCICI"] + ";" + dbrecords.rows.item(i)["SERIE"] + ";" + dbrecords.rows.item(i)["CALBARAN"] + ";" + miFormatoFecha(dbrecords.rows.item(i)["FECHA"]) + ";" + dbrecords.rows.item(i)["CCLIENTE"] + ";;" + straux + ";0;" + strAuxCobrado + ";" + dbrecords.rows.item(i)["TIPO"] + ";" + '"' + "" + Chr(13) + Chr(10);

        linea = 1;


        linea = linea + 1;
    }
    EmailText = "";
    Url = "http://kodeka.no-ip.info/file.php/?EmailTo=" + "c:\\gesmae\\" + strComercial + localStorage.intUltimoenvio + "ALB.TXT";
    req = Ajax(Url, "POST", EmailText);
    //  req=Ajax(url,"POST","/no-cache?" & Date)
    if (req.status == 200) { //success
        //   MsgBox("Email enviado")
    } else { //failure
        NSB.MsgBox("Error enviando cabecera " + req.err);
    }
    EmailText = "";
    Url = "http://kodeka.no-ip.info/file.php/?EmailTo=" + "c:\\gesmae\\" + strComercial + localStorage.intUltimoenvio + "ALBL.TXT";
    req = Ajax(Url, "POST", EmailText);
    //  req=Ajax(url,"POST","/no-cache?" & Date)
    if (req.status == 200) { //success
        //   MsgBox("Email enviado")
    } else { //failure
        NSB.MsgBox("Error enviando cabecera " + req.err);
    }


    EmailText = ALBARAN;
    Url = "http://kodeka.no-ip.info/file.php/?EmailTo=" + "c:\\gesmae\\" + strComercial + localStorage.intUltimoenvio + "COB.TXT";
    req = Ajax(Url, "POST", EmailText);
    //  req=Ajax(url,"POST","/no-cache?" & Date)
    if (req.status == 200) { //success
        NSB.MsgBox("Cobros Transmitidos");
    } else { //failure
        NSB.MsgBox("Error enviando cobros " + req.err);
    }

    localStorage.intUltimoenvio = _jsCint(localStorage.intUltimoenvio) + 1;
    if (localStorage.intUltimoenvio == 100) {
        localStorage.intUltimoenvio = 10;
    }


}

function resulcarga_compruebadbl(transaction, results) {
    var straux;
    dbrecords = results;
    if (dbrecords.rows.length == 0) {
        NSB.MsgBox("No hay lineas");
        return;
    }

    for (i = 0; i <= dbrecords.rows.length - 1; i++) {

        straux = "Albaran " + dbrecords.rows.item(i)["CALBARAN"] + " Art. " + dbrecords.rows.item(i)["CODIGOARTI"] + " UDS: " + dbrecords.rows.item(i)["UNIDADES"] + " PRECIO: " + dbrecords.rows.item(i)["PRECIO"];
        NSB.MsgBox(straux);
    }
}

function resulcarga_compruebadb(transaction, results) {
    var straux;
    dbrecords = results;
    if (dbrecords.rows.length == 0) {
        NSB.MsgBox("No hay albaranes");
        return;
    }

    for (i = 0; i <= dbrecords.rows.length - 1; i++) {

        straux = "Albaran " + dbrecords.rows.item(i)["CALBARAN"] + " Cliente " + dbrecords.rows.item(i)["CCLIENTE"] + " Serie " + dbrecords.rows.item(i)["SERIE"] + " Obs: " + dbrecords.rows.item(i)["OBS"];
        NSB.MsgBox(straux);
    }
}

function resulcarga_envioCobrosCompleto(transaction, results) {
    dbrecords = results;

    var albaranactual;
    var ALBARAN;
    var ALBARANL;

    var linea;

    //'  List1.deleteItem("all")
    var datos_lista = "";
    var straux, strAuxCobrado;
    var dato;
    j = 0;
    var intEnvioActual;
    ALBARAN = "";
    ALBARANL = "";
    albaranactual = "weñflkwelfkj";
    linea = 1;
    if (dbrecords.rows.length == 0) {
        NSB.MsgBox("No hay cobros");
        return;
    }
    // albaranactual=dbrecords.rows.item(0)["CALBARAN"]
    if (localStorage.intUltimoenvio > 9) {
        intEnvioActual = localStorage.intUltimoenvio;
    } else {
        intEnvioActual = 0 + localStorage.intUltimoenvio;
    }
    for (i = 0; i <= dbrecords.rows.length - 1; i++) {

        straux = CStr(dbrecords.rows.item(i)["IMPORTE"]);

        straux = Replace(straux, ".", ",");
        strAuxCobrado = CStr(dbrecords.rows.item(i)["COBROS"]);
        strAuxCobrado = Replace(strAuxCobrado, ".", ",");
        ALBARAN = ALBARAN + "" + '"' + "" + dbrecords.rows.item(i)["EJERCICI"] + ";" + dbrecords.rows.item(i)["SERIE"] + ";" + dbrecords.rows.item(i)["CALBARAN"] + ";" + miFormatoFecha(dbrecords.rows.item(i)["FECHA"]) + ";" + dbrecords.rows.item(i)["CCLIENTE"] + ";;" + straux + ";0;" + strAuxCobrado + ";" + dbrecords.rows.item(i)["TIPO"] + ";" + '"' + "" + Chr(13) + Chr(10);

        linea = 1;


        linea = linea + 1;
    }

    EmailText = ALBARAN;
    Url = "http://kodeka.no-ip.info/file.php/?EmailTo=" + "c:\\gesmae\\" + strComercial + localStorage.intUltimoenvio + "COB.TXT";
    req = Ajax(Url, "POST", EmailText);
    //  req=Ajax(url,"POST","/no-cache?" & Date)
    if (req.status == 200) { //success
        NSB.MsgBox("Albaranes y Cobros Enviados, FICHERO:" + intEnvioActual);
    } else { //failure
        NSB.MsgBox("Error enviando cobros " + req.err);
    }

    localStorage.intUltimoenvio = _jsCint(localStorage.intUltimoenvio) + 1;
    if (localStorage.intUltimoenvio == 100) {
        localStorage.intUltimoenvio = 10;
    }


}








Button4.onclick = function() {
    if (NSB.MsgBox("¿Desea ver las cabeceras de albaran de la base de datos?", 1) == 1) {

        sqlList = [];
        sqlList[0] = ["Select * from ALBARAN order by calbaran;", resulcarga_compruebadb];
        Sql(DB, sqlList);
    }

};


Button4Copy.onclick = function() {
    var i;
    if (NSB.MsgBox("¿Desea ver las lineas de albaranes de la base de datos?", 1) == 1) {
        i = prompt("Mostrar las lineas del albaran número...", 1);

        sqlList = [];
        sqlList[0] = ["Select * from ALBARANL where calbaran=" + i + " order by calbaran;", resulcarga_compruebadbl];
        Sql(DB, sqlList);
    }

};




txtCarga.onclick = function() {
    ChequearCarga();
};
function VAL(NumStr) {
    var returnValue = "";
    var negativo;
    negativo = 0;
    NumStr = Replace(NumStr, ",", ".");
    if (InStr(1, NumStr, "-")) {
        negativo = 1;
        NumStr = Replace(NumStr, "-", "");
    }
    if (IsNumeric(Left(NumStr, 1))) {
        if (InStr(1, NumStr, ".") == 0) { //Locate the first occurrence of a
            //decimal point
            //Integer found
            returnValue = _jsCint(NumStr);
        } else {
            //Floating-point found -> always return a double-precision number even
            // if the decimal point occurs in the non-numeric part of the overall string
            returnValue = parseFloat(NumStr);
        }
    } else {
        //String starts with non-numeric character -> evaluates to zero
        returnValue = 0;
    }
    if (negativo == 1) {
        returnValue = returnValue * -1;
    }
    return returnValue;
}


function fnGetRemoteData(remoteDB, txtSql) {
    var returnValue = "";

    req = Ajax(remoteDB, "POST", txtSql);
    if (req.status != 200) {

        NSB.MsgBox("Error");
        returnValue = "";
    } else {

        returnValue = req.responseText;

    }
    return returnValue;
}

function ChequearCarga() {
    var data;
    req = fnGetRemoteData(strRemoteDB, "SELECT * FROM cargas order by idcargas desc limit 1;");


    data = JSON.parse(req);

    if (DB != 0) {

        if (data[0].TIPO == "FINALIZADO") {
            txtCarga.value = "Disponible Carga del " + Mid(data[0].Inicio, 9, 2) + "/" + Mid(data[0].Inicio, 6, 2) + "/" + Left(data[0].Inicio, 4) + "  " + Right(data[0].Inicio, 8);
        } else {
            txtCarga.value = "Carga No Permitida";
        }
    }
}

function sbInicializar() {
    var strAux;
    var data, sqlList, q;
    var dataRecord;
    var arrayCampos;
    var intRegistros;
    var intOffset;
    var intCampos;
    var blnCambioTabla;
    var arRecord;
    var intsql;
    var strSql, strSqlInsert;
    var strTablaActual;
    var strCreate;
    var intSqlListIndex;

    var j;
    var maxregistros;
    currentrowppal = -1;

    //   sbEliminarTablas
    if (localStorage.comercial == "0") {
        NSB.MsgBox("Máquina sin comercial asignado. Es necesario asignarle uno");
        return;
    }

    if (txtCarga.value == "Carga No Permitida" || txtCarga.value == "Consultar Carga") {
        NSB.MsgBox("No se puede cargar la máquina no hay una carga completa en Kodeka");
        return;
    }

    //    intcomercial=InputBox("Introduzca el número de comercial", "", localStorage.comercial)
    //   localStorage.comercial =intcomercial 
    localStorage.intUltimoAlbaran = 0;
    // End If
    q = Chr(34);
    blnCambioTabla = true;

    NSB.WaitCursor(true);
    req = fnGetRemoteData(strRemoteDB, "select * from tablas order by tablas.table, orden;");


    data = JSON.parse(req);

    List1.show();

    strSql = "";
    sqlList = []; // Contiene las sql a ejecutar
    sqlListIndex = [];
    intSqlListIndex = 0;
    intsql = 0;

    if (DB != 0) {
        arRecord = data[0];
        for (i = 0; i <= UBound(data) - 1; i++) {
            if (i >= UBound(data) - 1) {
                break
            }
            if (i != 0) {
                arRecord = data[0];
            }
            //           
            if (i == 0 || blnCambioTabla) {
                if (i >= UBound(data) - 1) {
                    break
                }

                strCreate = "";
                strSql = "";
                strSqlInsert = "";
                strTablaActual = data[i].Table;
                offset = 10000;
                numeroregistros = 0;

                arrayCampos = []; //Contiene los campos de cada tabla para formar la insert
                intCampos = 0; // Contiene el numero de campo 
                strTablaActual = UCase(strTablaActual);

                sqlList[intsql] = ["DROP TABLE IF EXISTS " + UCase(strTablaActual) + ";"];
                intsql = intsql + 1;
                // MsgBox "" &  sqlList[0]
                // Sql  (DB,  sqlList)


                //     strDelete=" Delete  from  " &  strTablaActual & ";"
                strSqlInsert = "INSERT INTO " + strTablaActual + " values (";



                strCreate = "CREATE TABLE IF NOT EXISTS " + strTablaActual + "(";

                strCreate = strCreate + " '" + data[i].Campo + "' " + data[i].TYPES + " ";
                if (strTablaActual == "tablas") {
                    req = fnGetRemoteData(strRemoteDB, "select * from " + strTablaActual + "  limit 10000;");
                } else {

                    req = fnGetRemoteData(strRemoteDB, "select * from " + strTablaActual + "  where codigocomisionista='" + _jsCint(localStorage.comercial) + "' limit 10000;");
                }

                dataRecord = JSON.parse(req);

                arrayCampos[intCampos] = data[i].Campo;
                //strSqlInsert= strSqlInsert & " "   & data[i].Campo & ", "
                blnCambioTabla = false;
            } else if (data[i].Table == strTablaActual) {
                strCreate = strCreate + ", '" + data[i].Campo + "' " + data[i].TYPES + " ";

                arrayCampos[intCampos] = data[i].Campo;
                //INDICES!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

                if (data[i].Index == 1) {
                    sqlListIndex[intSqlListIndex] = ["Create index " + data[i].Table + "_" + data[i].Campo + " ON " + data[i].Table + " (" + data[i].Campo + ")"];
                    intSqlListIndex = intSqlListIndex + 1;
                }
                //INDICES!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!                   

            } else {
                strCreate = Left(strCreate, Len(strCreate) - 0) + ");";
                // sqlList=[]

                sqlList[intsql] = [strCreate];

                intsql = intsql + 1;
                //       sqlList[intsql]=strDelete
                //         intsql=intsql+1
                strDelete = "";
                //   Sql(DB,  sqlList)	
                strCreate = "";
                //  Exit Sub
                // strSqlInsert=strSqlInsert & ");"
                j = 0;
                maxregistro = UBound(dataRecord);
                while (j <= maxregistro) {


                    for (K = 0; K <= intCampos - 1; K++) {
                        if (K == 0) {
                            strAux = arrayCampos[K];
                            strSql = strSql + "'" + dataRecord[j][strAux] + "' ";
                        } else {
                            strAux = arrayCampos[K];
                            strSql = strSql + ", '" + dataRecord[j][strAux] + "' ";
                        }
                        //   lblFoot.value="Cargando " & strTablaActual & " / " & arrayCampos[k]
                        // MsgBox strSqlInsert 
                    }
                    //    lblFoot.value= "ejecutar " & strSqlInsert & strSql & ");"
                    //   sqlList = [] 
                    sqlList[intsql] = [strSqlInsert + strSql + ");"];
                    intsql = intsql + 1;

                    //  If j<10 Then MsgBox sqlList[0]
                    // 
                    numeroregistros = numeroregistros + 1;
                    //     If numeroregistros <3 Or numeroregistros >1997 Then  MsgBox "registros " & numeroregistros  & " offset & " & offset
                    strSql = "";
                    // If parar=1 And numeroregistros>3997 Then MsgBox "jota " & numeroregistros & " offset " & offset

                    if (numeroregistros == offset - 1) {
                        //  MsgBox "offset alcanzado en tabla " & strTablaActual  & " " &  offset & " / " &   numeroregistros

                        req = fnGetRemoteData(strRemoteDB, "select * from " + strTablaActual + " where codigocomisionista='" + _jsCint(localStorage.comercial) + "' limit 10000;");
                        offset = offset + 10000;
                        //  lblFoot.value="iniciando " & strTablaActual 
                        dataRecord = JSON.parse(req);
                        maxregistro = UBound(dataRecord);
                        //    MsgBox "reg " & numeroregistros & " maximo "  & maxregistro

                        j = 0;
                    } else {
                        j = j + 1;
                    }

                }

                //     MsgBox " fin " & strSqlInsert
                // Sql(DB,  sqlList)	
                strSql = "";



                blnCambioTabla = true;
                i = i - 1;
            }
            intCampos = intCampos + 1;

        }
    }

    Sql(DB, sqlList);
    if (intSqlListIndex > 0) {
        Sql(DB, sqlListIndex);
    }
    //

    NSB.WaitCursor(false);


    DB = SqlOpenDatabase("database.db", "1.0", "BaseKodeka");

    NSB.MsgBox("Carga de datos del comercial " + localStorage.comercial + " finalizada");

}

function miFormatoFecha(x) {
    var returnValue = "";
    var y, j;
    if (Len(x) > 0) {
        j = Mid(x, 9, 2) + "/" + Mid(x, 6, 2) + "/";
        y = Left(x, 4);
        y = Right(y, 2);
        x = j + y;
        returnValue = x;
    }
    return returnValue;
}

function fnUltimoAlbaran() {

    sqlList = [];
    sqlList[0] = ["Select max(calbaran) as ultimo from ALBARAN", resulcarga_ultimoalb];
    Sql(DB, sqlList);

}


function resulcarga_ultimoalb(transaction, results) {
    var strAux;
    dbrecords = results;
    if (dbrecords.rows.length == 0) {
        localStorage.intUltimoAlbaran = 0;
        return;
    } else {
        localStorage.intUltimoAlbaran = dbrecords.rows.item(i)["ultimo"];
    }

}

function ValorSinComas(x) {
    var returnValue = "";
    if (Len(x) > 0) {
        returnValue = Replace(x, ",", "");
    } else {
        returnValue = "";
    }
    return returnValue;
}

function yesNoDone(result) {
    if (result == 6) {
        NSB.MsgBox("Yes");
    } else {
        NSB.MsgBox("No");
    }
}
var strObservaciones;
var s;

var blnTecladoSucio;
var x, y;
var xx, yy;
var currentrow;
var gstrorderCobros;





function sbcargacobros(strWhere) {

    //   HeaderBar.title="Consultando Artículos"  

    sbBorrarGridCobros();
    //  WaitCursor True

    sqlList = [];
    if (strWhere == "") {
        if (blnResumenCobros == 0) {

            sqlList[0] = ["SELECT  COBROS.*, CLIENTE.NOMBRE from cobros INNER Join CLIENTE On COBROS.CCLIENTE=CLIENTE.CODIGOCLIE WHERE   codigoclie='" + txtcodigoclientecobro.value + "'" + gstrorderCobros + " limit 500;", resultcobros];
        } else {
            sqlList[0] = ["SELECT  COBROS.*, CLIENTE.NOMBRE from cobros INNER Join CLIENTE On COBROS.CCLIENTE=CLIENTE.CODIGOCLIE where COBROS.COBROS<>0  limit 900;", resultcobros];

        }
    } else {
        sqlList[0] = ["SELECT  COBROS.*, CLIENTE.NOMBRE from cobros INNER Join CLIENTE On COBROS.CCLIENTE=CLIENTE.CODIGOCLIE  WHERE " + strWhere + " and codigoclie  ='" + txtcodigoclientecobro.value + "'" + gstrorderCobros + " limit 200;", resultcobros];
    }


    dbrecords = [];
    Sql(DB, sqlList);
    currentrow = -1;
    sbActualizaRowCobros(-1);
    //   WaitCursor False
}

function sbrecalculacobros(strWhere) {
    NSB.WaitCursor(true);
    sqlList = [];
    if (strWhere == "") {

        sqlList[0] = ["SELECT  COBROS.* from cobros WHERE COBROS<>0  order by CCLIENTE, TIPO;", resultrecalculocobros];
    } else {
        sqlList[0] = ["SELECT  COBROS.* from cobros WHERE cobrOS<>0  order by CCLIENTE, TIPO;", resultrecalculocobros];
    }
    dbrecords = [];
    Sql(DB, sqlList); //

    NSB.WaitCursor(false);
}

function resultrecalculocobros(transaction, results) {
    // Called On completion of Sql command in Function btnRead_onclick
    // Called On completion of Sql command in Function btnRead_onclick
    var efectivo;
    var talon;
    var efectivoa;
    var talona;
    //MsgBox " Empieza"
    efectivo = 0;
    efectivoa = 0;
    talona = 0;
    talon = 0;
    var x;
    dbrecords = results;

    for (i = 0; i <= dbrecords.rows.length - 1; i++) {

        if (dbrecords.rows.item(i)["TIPO"] == "T") {
            if (dbrecords.rows.item(i)["CCLIENTE"] == txtcodigoclientecobro.value) {
                talona = talona + dbrecords.rows.item(i)["COBROS"];
            }
            talon = talon + dbrecords.rows.item(i)["COBROS"];
        }
        if (dbrecords.rows.item(i)["TIPO"] == "E") {
            if (dbrecords.rows.item(i)["CCLIENTE"] == txtcodigoclientecobro.value) {
                efectivoa = efectivoa + dbrecords.rows.item(i)["COBROS"];
            }
            efectivo = efectivo + dbrecords.rows.item(i)["COBROS"];
        }
        txtefectivot.value = FormatNumber(efectivo, 2);
        txttalont.value = FormatNumber(talon, 2);
        txtefectivo.value = FormatNumber(efectivoa, 2);
        txttalon.value.value = FormatNumber(talona, 2);
        txttotalcobradoresumen.value = FormatNumber(talon + efectivo, 2);
        txttotalcobradoresumen.show();
    }

}


function resultcobros(transaction, results) {
    // Called On completion of Sql command in Function btnRead_onclick
    var x;
    var j;
    var efectivoc;
    var talonc;
    var efectivoclte;
    var talonclte;
    var pte;
    var codigocliente;
    var nombrecliente;
    dbrecords = results;
    //For i=0 To   grdcobros.getRowCount()-1

    //  Next
    // RESUMEN DE COBROS
    //------------------------------------------------------------------------------------------
    if (blnResumenCobros == 1) {
        sbBorrarGridCobros();
        txtcodigoclientecobro.hide();
        txtnombreclientecobro.hide();
        talonclte = 0;
        efectivoclte = 0;
        btnGuardarCobro.hide();
        btnBorrarCobro.hide();
        btnPago.hide();
        txtImporte.hide();
        lblImporte.hide();



        efectivoc = 0;
        talonc = 0;
        //   SetTimeout(grdcobros.refresh(),3)
        grdcobros.hide();

        grdtitulocobro.hide();

        //   SetTimeout(grdcobrosresumen.refresh(),3)

        grdcobrosresumen.show();
        //    grdcobrosresumen.refresh()
        codigocliente = "";
        nombrecliente = "";


        grdtitulocobroresumen.show();
        j = 0;
        //   SetTimeout(grdcobrosresumen.refresh(),3)
        //   grdcobrosresumen.addRows(dbrecords.rows.length) 
        //grdcobrosresumen.addRows(1) 
        grdcobrosresumen.refresh();
        for (i = 0; i <= dbrecords.rows.length - 1; i++) {

            if (StrComp(dbrecords.rows.item(i)["CCLIENTE"], codigocliente, 1) != 0) {
                grdcobrosresumen.addRows(1);
                grdcobrosresumen.cell(j, 0).style.fontSize = "16px";
                grdcobrosresumen.setValue(j, 0, 0);
                grdcobrosresumen.cell(j, 0).style.textAlign = "right";
                grdcobrosresumen.cell(j, 0).style.color = "black";
                grdcobrosresumen.setValue(j, 0, dbrecords.rows.item(i)["CCLIENTE"]);
                grdcobrosresumen.cell(j, 0).style.background = "white";
                grdcobrosresumen.cell(j, 1).style.fontSize = "16px";
                grdcobrosresumen.setValue(j, 1, dbrecords.rows.item(i)["NOMBRE"]);
                grdcobrosresumen.cell(j, 2).style.fontSize = "16px";
                grdcobrosresumen.setValue(j, 2, FormatNumber(efectivoc, 2));
                grdcobrosresumen.cell(j, 3).style.fontSize = "16px";
                grdcobrosresumen.setValue(j, 3, FormatNumber(talonc, 2));
                grdcobrosresumen.cell(j, 3).style.textAlign = "right";
                grdcobrosresumen.cell(j, 4).style.fontSize = "16px";

                efectivoc = 0;
                talonc = 0;
                codigocliente = dbrecords.rows.item(i)["CCLIENTE"];
                nombrecliente = dbrecords.rows.item(i)["NOMBRE"];
                j = j + 1;
            }

            x = dbrecords.rows.item(i)["CALBARAN"];
            if (Len(x) > 1) {

                if (dbrecords.rows.item(i)["TIPO"] == "T") {
                    talonc = talonc + dbrecords.rows.item(i)["COBROS"];
                }
                if (dbrecords.rows.item(i)["TIPO"] == "E") {
                    efectivoc = efectivoc + dbrecords.rows.item(i)["COBROS"];
                }
                grdcobrosresumen.setValue(j - 1, 3, FormatNumber(talonc, 2));
                grdcobrosresumen.setValue(j - 1, 2, FormatNumber(efectivoc, 2));
                grdcobrosresumen.setValue(j - 1, 4, FormatNumber(talonc + efectivoc, 2));
                txttotalcobradoresumen.value = FormatNumber(talonc + efectivoc, 2);
                txttotalcobradoresumen.show;
            }
        }
        txtefectivot.show();
        txttalont.show();
        txtefectivo.hide();
        txttalon.hide();
        // COBROS
        //-----------------------------------------------------------------------------------------       
    } else {
        sbBorrarGridCobros();
        grdcobrosresumen.hide();

        grdtitulocobroresumen.hide();
        grdcobros.show();
        grdtitulocobro.show();
        grdcobros.refresh();
        //   SetTimeout(grdcobros.refresh(),1)
        talonclte = 0;
        efectivoclte = 0;
        grdcobros.style.tableLayout = "Fixed";
        //  MsgBox "" &  dbrecords.rows.length
        for (i = 0; i <= dbrecords.rows.length - 1; i++) {
            x = dbrecords.rows.item(i)["CALBARAN"];

            if (Len(x) > 1) {
                grdcobros.addRows(1);

                grdcobros.cell(i, 0).style.fontSize = "16px";
                grdcobros.setValue(i, 0, 0);
                grdcobros.cell(i, 0).style.textAlign = "right";
                grdcobros.cell(i, 0).style.color = "black";
                grdcobros.setValue(i, 0, dbrecords.rows.item(i)["EJERCICI"]);
                grdcobros.cell(i, 0).style.background = "white";
                grdcobros.cell(i, 1).style.fontSize = "16px";

                grdcobros.setValue(i, 1, dbrecords.rows.item(i)["CALBARAN"]);
                grdcobros.cell(i, 2).style.fontSize = "16px";
                grdcobros.setValue(i, 2, dbrecords.rows.item(i)["SERIE"]);
                grdcobros.cell(i, 3).style.fontSize = "16px";
                grdcobros.setValue(i, 3, dbrecords.rows.item(i)["IMPORTE"]);
                grdcobros.cell(i, 3).style.textAlign = "right";
                grdcobros.cell(i, 4).style.fontSize = "16px";
                pte = dbrecords.rows.item(i)["IMPORTE"] - dbrecords.rows.item(i)["COBRADO"] - dbrecords.rows.item(i)["COBROS"];
                grdcobros.setValue(i, 4, FormatNumber(pte, 2));
                if (grdcobros.getValue(i, 4) == 0) {
                    grdcobros.cell(i, 0).style.background = "green";
                } else if (pte < grdcobros.getValue(i, 3)) {
                    grdcobros.cell(i, 0).style.background = "orange";

                } else {
                    grdcobros.cell(i, 0).style.background = "white";
                }
                if (grdcobros.getValue(i, 4) == 0 && grdcobros.getValue(i, 6) == 0) {
                    grdcobros.cell(i, 0).style.background = "brown";
                }
                grdcobros.cell(i, 4).style.textAlign = "right";
                grdcobros.cell(i, 5).style.fontSize = "16px";
                grdcobros.setValue(i, 5, dbrecords.rows.item(i)["TIPO"]);
                grdcobros.cell(i, 5).style.textAlign = "right";
                grdcobros.cell(i, 6).style.fontSize = "16px";
                grdcobros.setValue(i, 6, FormatNumber(dbrecords.rows.item(i)["COBROS"], 2));
                grdcobros.cell(i, 6).style.textAlign = "right";
                grdcobros.cell(i, 9).style.fontSize = "16px";
                grdcobros.setValue(i, 9, dbrecords.rows.item(i)["COBRADO"]);
                grdcobros.cell(i, 9).style.textAlign = "right";
                grdcobros.cell(i, 7).style.fontSize = "16px";
                grdcobros.setValue(i, 7, FormatDateTime(dbrecords.rows.item(i)["FECHA"], 9));
                grdcobros.cell(i, 7).style.textAlign = "right";
                grdcobros.cell(i, 8).style.fontSize = "16px";
                grdcobros.setValue(i, 10, dbrecords.rows.item(i)["OBS"]);

                grdcobros.cell(i, 10).style.color = "transparent";

                //   grdcobros.cell(i+1,11).style.fontSize="10px"
                grdcobros.setValue(i, 11, dbrecords.rows.item(i)["ID"]);
                //  grdcobros.setValue(i,11,dbrecords.rows.item(i)["ID"])
                grdcobros.cell(i, 11).style.color = "transparent";
                grdcobros.cell(i, 10).style.color = "transparent";
                grdcobros.cell(i, 9).style.color = "transparent";
                x = DateDiff("d", dbrecords.rows.item(i)["FECHA"], DateAdd("s", 0, new Date()));
                x = Math.abs(x);
                // If x<8 Then
                //   grdcobros.cell(i,1).style.background = "green"
                // ElseIf x<30 Then
                //   grdcobros.cell(i,1).style.background = "gray"
                if (x > 30) {
                    // grdcobros.cell(i,7).style.background = "brown"
                    grdcobros.cell(i, 7).style.color = "red";
                } else {
                    //  grdcobros.cell(i,7).style.background = "dark"
                    grdcobros.cell(i, 7).style.color = "black";
                }
            }
            if (dbrecords.rows.item(i)["TIPO"] == "T") {
                talonclte = talonclte + dbrecords.rows.item(i)["COBROS"];
            }
            if (dbrecords.rows.item(i)["TIPO"] == "E") {
                efectivoclte = efectivoclte + dbrecords.rows.item(i)["COBROS"];
            }



        }

        txtefectivo.value = FormatNumber(efectivoclte, 2);
        txttalon.value = FormatNumber(talonclte, 2);
        txttotalcobradoresumen.value = "";
        txttotalcobradoresumen.hide();
        txtefectivot.hide();
        txttalont.hide();
        txtefectivo.show();

        txttalon.show();
        grdcobros.refresh();
        grdcobros.show();
        txttotalcobradoresumen.value = "";
        txttotalcobradoresumen.hide();
        // SetTimeout(grdcobros.refresh(),1) 
    }
    sbrecalculacobros()("");
    //  Call lblStatusUpdate()
    //  SetTimeout(grdcobros.refresh(),100)

}



grdcobros.onclick = function() {

    //Dim nohistorico  
    s = Split(event.target.id, "_");

    //MsgBox "Click on " & s(0) & " at row " & s(1) & " and column " & s(2)
    if (Len(grdcobros.getValue(s[1], 0)) == 0) {
        txtImporte.value = 0;
        btnGuardarCobro.hide();
        return;

    }

    if (currentrow == s[1]) {
        // MsgBox "con"
        return;

    }

    sbActualizaRowCobros(s[1]);

    sbCargaCobro();

    bGuardar.show();

};

function sbCargaCobro() {
    var intunidades;
    var txtarti;
    if (grdcobros.getValue(currentrow, 6) != 0) {
        txtImporte.value = grdcobros.getValue(currentrow, 4); // -  grdcobros.getValue(currentrow,6)  
    } else {
        txtImporte.value = VAL(ValorSinComas(grdcobros.getValue(currentrow, 4)));
    }
    if (grdcobros.getValue(currentrow, 5) == "T") {
        btnPago.value = 2;
    } else {

        btnPago.value = 1;
    }
    // sbabrirteclado
    btnGuardarCobro.show();
    return;

}
frmCobros.onshow = function() {
    sbBorrarGridCobros();
    btnPago.setValue(1, true);
    btnPago.setValue(2, false);
    gstrorderCobros = " order by CALBARAN asc";
    if (blnResumenCobros == 1) {
        blnResumenCobros = 0;
        //btnResumenCobros.innerText="Cobros Cliente"
        btnResumenCobros.onclick();
        // btnResumenCobros.hide()
        //  btnResumenCobros_onclick()
        //  Exit Function


        txtefectivo.value = 0;
        txttalon.value = 0;
        txtefectivot.value = 0;
        txttalont.value = 0;
        grdcobros.focus();




    } else {
        blnResumenCobros = 1;
        // btnResumenCobros.innerText="Resumen Cobrado"
        btnResumenCobros.onclick();
        grdcobrosresumen.focus();
    }
    btnResumenCobros.show();
    sbcargacobros("");
    //grdcobros.blur()
    //frmCobros.reset()

};

function sbActualizaRowCobros(v) {

    if (currentrow == -1 && v == -1) {
        return;
    }
    //MsgBox " x es " & v & " / " & currentrow
    if (currentrow == -1) {
        // MsgBox " menos 1"
        for (z = 1; z <= 11; z++) {


            grdcobros.cell(v, z).style.background = "yellow";
        }
    }

    if (currentrow != -1) {
        // MsgBox " no menos 1"
        for (z = 1; z <= 11; z++) {
            grdcobros.cell(currentrow, z).style.background = "transparent";
            grdcobros.cell(v, z).style.background = "yellow";

        }
    }
    currentrow = v;
}









btnGuardarCobro.onclick = function() {
    var misql;
    var intaux;


    // If  False Then ' btnPago.value="Borrar" Then
    // misql=misql  & " COBROS=0, "  
    //ElseIf 
    intaux = VAL(grdcobros.getValue(currentrow, 9));
    intaux = txtImporte.value - intaux;
    intaux = FormatNumber(intaux, 2);
    //'''' misql=misql & " COBROS=" & intaux   & ", " 
    misql = "Update COBROS set COBros=" + VAL(txtImporte.value) + ", ";
    //MsgBox btnPago.value()
    if (btnPago.getValue(1)) {
        misql = misql + " TIPO='E' ";
        grdcobros.setValue(currentrow, 5, "E");
    } else if (btnPago.getValue(2)) {
        grdcobros.setValue(currentrow, 5, "T");
        misql = misql + " TIPO='T' ";

    } else {
        grdcobros.setValue(currentrow, 5, ".");
        misql = misql + " TIPO='.' ";

    }

    misql = misql + " where ID='" + grdcobros.getValue(currentrow, 11) + "';";
    // MsgBox "" & misql
    sqlList = [];
    sqlList[0] = misql;
    Sql(DB, sqlList);
    intaux = FormatNumber(parseFloat(grdcobros.getValue(currentrow, 3)) - parseFloat(txtImporte.value) - parseFloat(grdcobros.getValue(currentrow, 9)), 2);
    grdcobros.setValue(currentrow, 4, VAL(intaux));
    // MsgBox "" & VAL(txtImporte.value)
    grdcobros.setValue(currentrow, 6, VAL(txtImporte.value));
    if (intaux == 0) {
        grdcobros.cell(currentrow, 0).style.background = "green";
    } else if (intaux < VAL(grdcobros.getValue(currentrow, 3))) {
        grdcobros.cell(currentrow, 0).style.background = "orange";
    } else {
        grdcobros.cell(currentrow, 0).style.background = "white";
    }
    recalculocobros();
    //      sbrecalculacobros ("")
    if (txtImporte.value == 0) {
        //      MsgBox "Cobro anulado"
    } else {
        //   MsgBox "Cobro guardado"
    }
};

function sbGuardaCobro(j) {
    var misql;
    var intaux;
    misql = "Update COBROS set  COBROS=IMPORTE-COBRADO , ";


    intaux = VAL(grdcobros.getValue(j, 6));
    intaux = txtImporte.value - intaux;
    intaux = FormatNumber(intaux, 2);
    //misql=misql & " COBROS=IMPORTE-COBRADO, " 

    if (btnPago.getValue(1)) {
        misql = misql + " TIPO='E' ";
        grdcobros.setValue(j, 5, "E");
    } else if (btnPago.getValue(2)) {
        grdcobros.setValue(j, 5, "T");
        misql = misql + " TIPO='T' ";

    } else {
        grdcobros.setValue(j, 5, ".");
        misql = misql + " TIPO='.' ";

    }

    misql = misql + " where ID='" + grdcobros.getValue(j, 11) + "';";
    // MsgBox "" & misql
    sqlList = [];
    sqlList[0] = misql;
    Sql(DB, sqlList);
    //  intaux=FormatNumber(VAL(grdcobros.getValue(currentrow,3))-VAL(txtImporte.value),2)
    // grdcobros.setValue(currentrow,4,VAL(intaux))
    // MsgBox "" & VAL(txtImporte.value)
    //  grdcobros.setValue(currentrow,6,VAL(txtImporte.value))
    // If intaux=0 Then
    //     grdcobros.cell(currentrow,0).style.background = "green"
    //'  ElseIf intaux<VAL(grdcobros.getValue(currentrow,3)) Then
    //'       grdcobros.cell(currentrow,0).style.background = "orange"
    // Else
    //   grdcobros.cell(currentrow,0).style.background = "white"
    //  End If
    //  recalculocobros
    //    sbrecalculacobros ("")
    // If txtImporte.value=0 Then
    //      MsgBox "Cobro anulado"
    //  Else
    //   MsgBox "Cobro guardado"
    //End If
}

TitleBarCobros.onclick = function(choice) {


    switch (true) {
        case ((choice) == "Inicio"):
            var continue1;
            var i;
            continue1 = NSB.MsgBox("¿Desea salir?", 1);
            if (continue1 == 1) {
                currentrow = -1;
                // frmPrincipal.style.webkitTransitionDuration="1000ms" 'take 1 second to do this.
                // frmPrincipal.style.webkitTransform="translateX(-" & SysInfo(0) & "px)" 'slide left
                txtImporte.value = "";
                //  txtnombrearticuloalbaran.value=""
                //Wait for the transition to complete half way before starting form2
                // SetTimeout(frmprincipaltoshow,1000)
                sbBorrarGridCobros();
                ChangeForm(frmPrincipal);
            }
            break;
        default:
            if (blnResumenCobros == 1) {
                btnResumenCobros.innerText = "Cobros Cliente";
            } else {
                btnResumenCobros.innerText = "Resumen Cobrado";
            }


    }

    //    Call
};

btnBorrarCobro.onclick = function() {
    var anterior;
    txtImporte.value = 0;


    grdcobros.setValue(currentrow, 6, 0);
    txtImporte.value = 0;

    grdcobros.setValue(currentrow, 5, "");
    //  MsgBox "Cobro anulado"
    btnGuardarCobro.onclick();

};

function recalculocobros() {
    var i;
    var inttalon;
    var intefectivo;
    sbrecalculacobros()("");


    inttalon = 0;
    intefectivo = 0;
    txttalon.value = 0;
    txtefectivo.value = 0;
    for (i = 0; i <= grdcobros.getRowCount() - 1; i++) {
        if (grdcobros.getValue(i, 5) == "T") {
            inttalon = FormatNumber((parseFloat(inttalon)) + parseFloat(grdcobros.getValue(i, 6)) - parseFloat(grdcobros.getValue(i, 9)), 2);
        } else if (grdcobros.getValue(i, 5) == "E") {
            intefectivo = FormatNumber(parseFloat(intefectivo) + parseFloat(grdcobros.getValue(i, 6)) - parseFloat(grdcobros.getValue(i, 9)), 2);

        }
        txttalon.value = Round(inttalon, 2);
        txtefectivo.value = Round(intefectivo, 2);
    }

}



btnResumenCobros.onclick = function() {


    if (blnResumenCobros == 0) {
        // grdcobrosresumen.Height=0
        // grdcobros.Height="Auto"
        btnResumenCobros.innerText = "Cobros Cliente";
        blnResumenCobros = 1;
        txtcodigoclientecobro.hide();
        txtnombreclientecobro.hide();
        //    grdtitulocobro.hide()
        //   grdcobros.hide()
        btnGuardarCobro.hide();
        btnBorrarCobro.hide();
        btnPago.hide();
        txtImporte.hide();
        lblImporte.hide();
        currentrow = -1;


    } else {
        if (Len(txtcodigoclientecobro.value) > 3) {
            //    grdcobrosresumen.Height="Auto"
            // grdcobros.Height=0
            btnResumenCobros.innerText = "Resumen Cobrado";
            blnResumenCobros = 0;
            txtcodigoclientecobro.show();
            txtnombreclientecobro.show();
            //   grdtitulocobro.show()
            //   grdcobros.show()

            btnGuardarCobro.show();
            btnBorrarCobro.show();
            btnPago.show();
            txtImporte.show();
            lblImporte.show();

            btnCobrarTodo.show();

        } else if (txtcodigoclientecobro == "") {

            // grdcobros.Height=0
            btnResumenCobros.innerText = "Resumen Cobrado";
            blnResumenCobros = 0;
            txtcodigoclientecobro.show();
            txtnombreclientecobro.show();
            //   grdtitulocobro.show()
            //   grdcobros.show()

            btnGuardarCobro.show();
            btnBorrarCobro.show();
            btnCobrarTodo.hide();
            btnPago.show();
            txtImporte.show();
            lblImporte.show();

            // ,30,20, 10,90,90,20,70,26,0,0
        }
    }
    sbcargacobros("");
};






btnCobrarTodo.onclick = function() {
    var i;
    if (blnResumenCobros == 0) {
        for (i = 0; i <= grdcobros.getRowCount() - 1; i++) {
            //currentrow=ifrmCobros.
            sbGuardaCobro(i);

        }
        currentrow = -1;
        sbcargacobros("");
    }
};

function sbBorrarGridCobros() {
    for (i = 0; i <= grdcobros.getRowCount() - 1; i++) {
        grdcobros.deleteRows(1);
    }
    for (i = 0; i <= grdcobrosresumen.getRowCount() - 1; i++) {
        grdcobrosresumen.deleteRows(1);
    }
    //  grdcobrosresumen.deleteRows(grdcobrosresumen.getRowCount()-1)
    //  grdcobros.deleteRows(grdcobros.getRowCount()-1)



    //    grdcobrosresumen.deleteRows(grdcobrosresumen.getRowCount()-1)
    for (i = 0; i <= grdcobros.getColCount() - 1; i++) {
        grdcobros.setValue(0, i, " ");
        grdcobros.cell(0, i).style.background = "transparent";
    }
    for (i = 0; i <= grdcobrosresumen.getColCount() - 1; i++) {
        grdcobrosresumen.setValue(0, i, " ");
        grdcobrosresumen.cell(0, i).style.background = "transparent";
    }
    //  If grdcobros.getRowCount()=1 Then grdcobros.deleteRow(0)
    //  If grdcobrosresumen.getRowCount()=1 Then     grdcobrosresumen.deleteRow(0)
    //   grdcobrosresumen.addRows(1)
    //   grdcobros.addRows(1)
    //   grdcobrosresumen.refresh()
    //  grdcobros.refresh()
    //   Next

}
txtImporte.onclick = function() {
    txtImporte.value = "";
};
var strObservaciones;
var s;
var intarticulo;
var intUnidadesCaja;
var blnTecladoSucio;
var x, y;
var xx, yy;
var currentrow;
var gstrorder;
var blnAlbaranEditado;
var arrayListaAlbaran;

var current_target;

var statusteclado; // 0 MEtiendo unidades, 1 metiendo unidades, 3 metidendotarifa





function sbcargahistorico(strWhere) {

    sbInicializarDatosArticulo();
    if (strWhere == "") {
        btnHistorico.hide();
    } else {
        btnHistorico.show();
    }
    NSB.WaitCursor(true);
    //  sbCerrarTeclado
    arrayLista = [];
    sqlList = [];
    switch (true) {
        case ((txtSerie.value) == "CA"):
            strWhere = filtroCA + strWhere;
            break;
        case ((txtSerie.value) == "55"):
            strWhere = filtro55 + strWhere;
            break;
        default:
            strWhere = " 1=1 and " + strWhere;
    }
    //  If strWhere="" Then

    //         sqlList[0]=["SELECT  * from frecuenc  WHERE unidades<>'null' and  codigoclie='" & txtcodigoclientealbaran.value & "'"  & gstrorder &   " limit 700;", resultartalbaranes]
    //     Else
    var auxpromo;
    auxpromo = flipPromo.value;
    if (auxpromo != "Ver Todos") {
        strWhere = "  CPROMO>0 and " + strWhere;
    }

    //If Not Right(RTrim(strWhere),3)="and" Then
    //        strWhere=strWhere & " and "
    //     End If 
    if (strEstadoAnadir != "Pedido") {

        sqlList[0] = ["SELECT  * from frecuenc  WHERE unidades<>'null' and " + strWhere + "  codigoclie  ='" + txtcodigoclientealbaran.value + "'" + gstrorder + " limit 720;", resultartalbaranes];
    } else {
        sqlList[0] = ["SELECT  * from frecuenc  WHERE " + strWhere + " and codigoclie  ='" + txtcodigoclientealbaran.value + "'" + gstrorder + " limit 710;", resultartalbaranes_pedido];
    }
    //   End If 



    Sql(DB, sqlList);

    sbActualizaRow(-1);

    NSB.WaitCursor(false);
}

function resultartalbaranes_pedido(transaction, results) {
    // Called On completion of Sql command in Function btnRead_onclick
    var x;
    var dblTotal, dblActual;
    dblTotal = 0;
    sbBorraGridArticulos();
    dbrecords = results;
    arrayListaAlbaran = createMultiDimArray(dbrecords.rows.length, 12);

    grdarticulos.hide();
    //  btnHistorico.hide()
    btnAnadirArticulo.show();
    grdarticulos.Width = "100%";
    grdtitulo.setValue(0, 7, "SUBTOTAL");
    currentrow = -1;
    //   grdarticulos.show()
    for (i = 0; i <= dbrecords.rows.length - 1; i++) {
        grdarticulos.addRows(1);
        dblActual = dbrecords.rows.item(i)["PPEDIDO"] * dbrecords.rows.item(i)["PPRECIO"] * (100 - dbrecords.rows.item(i)["PDTO"]) / 100;

        dblTotal = dblTotal + dblActual;
        if (Len(dbrecords.rows.item(i)["CODIGOARTI"]) > 1) {
            arrayListaAlbaran[i, 0] = dbrecords.rows.item(i)["PPEDIDO"];
            arrayListaAlbaran[i, 1] = dbrecords.rows.item(i)["CODIGOARTI"];
            arrayListaAlbaran[i, 2] = dbrecords.rows.item(i)["DESCRIPCIO"];
            arrayListaAlbaran[i, 3] = dbrecords.rows.item(i)["BULTOS"];

            arrayListaAlbaran[i, 4] = dbrecords.rows.item(i)["PTARIFA"];
            arrayListaAlbaran[i, 5] = dbrecords.rows.item(i)["PPRECIO"];

            arrayListaAlbaran[i, 7] = FormatNumber(dblActual, 2);
            arrayListaAlbaran[i, 6] = dbrecords.rows.item(i)["PPEDIDO"];
            arrayListaAlbaran[i, 9] = dbrecords.rows.item(i)["PDTO"];
            if (arrayListaAlbaran[i, 9] == "") {
                arrayListaAlbaran[i, 9] = "0";
            }
            arrayListaAlbaran[i, 12] = dbrecords.rows.item(i)["ID"];


            grdarticulos.cell(i, 0).style.fontSize = "16px";
            grdarticulos.setValue(i, 0, dbrecords.rows.item(i)["PPEDIDO"]);
            grdarticulos.cell(i, 0).style.textAlign = "right";
            grdarticulos.cell(i, 0).style.color = "black";
            grdarticulos.cell(i, 1).style.background = "transparent";
            grdarticulos.cell(i, 0).style.background = "white";
            grdarticulos.cell(i, 1).style.fontSize = "16px";
            grdarticulos.setValue(i, 1, dbrecords.rows.item(i)["CODIGOARTI"]);
            grdarticulos.cell(i, 2).style.fontSize = "16px";
            grdarticulos.setValue(i, 2, dbrecords.rows.item(i)["DESCRIPCIO"]);
            grdarticulos.cell(i, 3).style.fontSize = "16px";
            grdarticulos.setValue(i, 3, dbrecords.rows.item(i)["BULTOS"]);
            grdarticulos.cell(i, 3).style.textAlign = "right";
            grdarticulos.cell(i, 4).style.fontSize = "16px";
            grdarticulos.setValue(i, 4, dbrecords.rows.item(i)["PTARIFA"]);
            grdarticulos.cell(i, 4).style.textAlign = "right";
            grdarticulos.cell(i, 5).style.fontSize = "16px";
            grdarticulos.setValue(i, 5, dbrecords.rows.item(i)["PPRECIO"]);
            grdarticulos.cell(i, 5).style.textAlign = "right";
            // grdarticulos.cell(i,6).style.fontSize="10px"
            //  grdarticulos.setValue(i,6,"") 'dbrecords.rows.item(i)["FECHA"])
            grdarticulos.cell(i, 6).style.fontSize = "16px";
            grdarticulos.setValue(i, 6, dbrecords.rows.item(i)["PPEDIDO"]);
            grdarticulos.cell(i, 6).style.textAlign = "right";
            grdarticulos.cell(i, 7).style.fontSize = "16px";
            grdarticulos.setValue(i, 7, FormatNumber(dblActual, 2));
            grdarticulos.cell(i, 7).style.textAlign = "right";

            if (dbrecords.rows.item(i)["INTPROMO"] > 0) {
                grdarticulos.cell(i, 2).style.color = "red";
            } else {
                grdarticulos.cell(i, 2).style.color = "black";
            }




        }


    }
    // ImporteAlbaranTotal.show()
    lblAlbaranTotal.show();
    //  ImporteAlbaranTotal.value=Round(dblTotal,2)
    //  Call lblStatusUpdate()
    //SetTimeout(grdarticulos.refresh(),1)
    grdarticulos.show();
    grdarticulos.refresh();


}

function resultartalbaranes(transaction, results) {
    // Called On completion of Sql command in Function btnRead_onclick
    var x;
    sbBorraGridArticulos();
    dbrecords = results;
    grdtitulo.setValue(0, 7, "UltimoPed.");

    grdarticulos.hide();
    //  btnHistorico.hide()
    btnAnadirArticulo.show();
    dblActual = 0;

    dblTotal = 0;

    arrayListaAlbaran = createMultiDimArray(dbrecords.rows.length, 12);
    for (i = 0; i <= dbrecords.rows.length - 1; i++) {
        dblActual = dbrecords.rows.item(i)["PPEDIDO"] * dbrecords.rows.item(i)["PPRECIO"] * (100 - dbrecords.rows.item(i)["PDTO"]) / 100;

        arrayListaAlbaran[i, 1] = dbrecords.rows.item(i)["CODIGOARTI"];
        arrayListaAlbaran[i, 2] = dbrecords.rows.item(i)["DESCRIPCIO"];
        arrayListaAlbaran[i, 3] = dbrecords.rows.item(i)["BULTOS"];

        arrayListaAlbaran[i, 4] = dbrecords.rows.item(i)["TARIFA"];
        arrayListaAlbaran[i, 5] = dbrecords.rows.item(i)["PRECIO"];

        arrayListaAlbaran[i, 7] = dbrecords.rows.item(i)["ULTIMACOMPRA"];
        arrayListaAlbaran[i, 6] = dbrecords.rows.item(i)["UNIDADES"];
        //arrayListaAlbaran[i,8]=dbrecords.rows.item(i)["DIASULTIMACOMPRA"]
        arrayListaAlbaran[i, 8] = dbrecords.rows.item(i)["PPEDIDO"];
        arrayListaAlbaran[i, 9] = dbrecords.rows.item(i)["PDTO"];
        if (arrayListaAlbaran[i, 9] == "") {
            arrayListaAlbaran[i, 9] = "0";
        }
        arrayListaAlbaran[i, 10] = dbrecords.rows.item(i)["PPRECIO"];
        arrayListaAlbaran[i, 11] = dbrecords.rows.item(i)["PTARIFA"];
        arrayListaAlbaran[i, 12] = dbrecords.rows.item(i)["ID"];






        dblTotal = dblTotal + dblActual;
        grdarticulos.addRows(1);
        if (Len(dbrecords.rows.item(i)["CODIGOARTI"]) > 1) {

            grdarticulos.cell(i, 1).style.background = "transparent";
            grdarticulos.cell(i, 0).style.fontSize = "16px";
            //   grdarticulos.setValue(i,0,0)
            grdarticulos.cell(i, 0).style.textAlign = "right";
            grdarticulos.cell(i, 0).style.color = "black";

            grdarticulos.cell(i, 0).style.background = "white";
            grdarticulos.cell(i, 1).style.fontSize = "16px";
            grdarticulos.setValue(i, 1, dbrecords.rows.item(i)["CODIGOARTI"]);

            grdarticulos.cell(i, 2).style.fontSize = "16px";
            grdarticulos.setValue(i, 2, dbrecords.rows.item(i)["DESCRIPCIO"]);

            grdarticulos.cell(i, 3).style.fontSize = "16px";
            grdarticulos.setValue(i, 3, dbrecords.rows.item(i)["BULTOS"]);

            grdarticulos.cell(i, 3).style.textAlign = "right";
            grdarticulos.cell(i, 4).style.fontSize = "16px";
            grdarticulos.setValue(i, 4, dbrecords.rows.item(i)["TARIFA"]);

            grdarticulos.cell(i, 4).style.textAlign = "right";
            grdarticulos.cell(i, 5).style.fontSize = "16px";
            grdarticulos.setValue(i, 5, dbrecords.rows.item(i)["PRECIO"]);

            grdarticulos.cell(i, 5).style.textAlign = "right";

            grdarticulos.cell(i, 6).style.fontSize = "16px";
            grdarticulos.setValue(i, 6, dbrecords.rows.item(i)["UNIDADES"]);

            grdarticulos.cell(i, 6).style.textAlign = "right";
            grdarticulos.cell(i, 7).style.fontSize = "16px";
            x = dbrecords.rows.item(i)["ULTIMACOMPRA"];

            x = Mid(x, 9, 2) + "/" + Mid(x, 6, 2) + "/" + Left(x, 4);
            grdarticulos.setValue(i, 7, x);
            grdarticulos.cell(i, 7).style.textAlign = "right";

            grdarticulos.setValue(i, 0, dbrecords.rows.item(i)["PPEDIDO"]);
            arrayListaAlbaran[i, 0] = dbrecords.rows.item(i)["PPEDIDO"];
            if (dbrecords.rows.item(i)["PPEDIDO"] > 0 || dbrecords.rows.item(i)["PPEDIDO"] < 0) {
                grdarticulos.cell(i, 0).style.background = "blue";
                grdarticulos.cell(i, 0).style.color = "yellow";
            } else if (dbrecords.rows.item(i)["PPEDIDO"] == 0) {
                grdarticulos.cell(i, 0).style.background = "white";
                grdarticulos.cell(i, 0).style.color = "black";
            } else {
                grdarticulos.cell(i, 0).style.background = "blue";
                grdarticulos.cell(i, 0).style.color = "yellow";
            }

            grdarticulos.cell(i, 0).style.textAlign = "right";
            if (dbrecords.rows.item(i)["CPROMO"] > 0) {
                grdarticulos.cell(i, 2).style.color = "red";
            } else {
                grdarticulos.cell(i, 2).style.color = "black";
            }

            x = dbrecords.rows.item(i)["DIASULTIMACOMPRA"];

            x = Math.abs(x);
            if (x < 8) {
                grdarticulos.cell(i, 1).style.background = "Chartreuse";
                grdarticulos.cell(i, 1).style.color = "black";
            } else if (x < 15) {
                grdarticulos.cell(i, 1).style.background = "Green";
                grdarticulos.cell(i, 1).style.color = "black";
            } else if (x < 30) {
                grdarticulos.cell(i, 1).style.background = "Olive";
                grdarticulos.cell(i, 1).style.color = "white";
            } else {
                grdarticulos.cell(i, 1).style.background = "DarkGreen";
                grdarticulos.cell(i, 1).style.color = "white";
            }
        }






    }
    if (dbrecords.rows.length == 0) {
        var auxpromo;
        auxpromo = flipPromo.value;
        if (auxpromo == "Ver Todos") {
            NSB.MsgBox("No se han encontrado artículos en el histórico del cliente");
        } else {
            NSB.MsgBox("No se han encontrado artículos actualmente en promoción en el histórico del cliente");
        }
    }
    grdarticulos.Width = "100%";
    // ImporteAlbaranTotal.show()
    lblAlbaranTotal.show();
    grdarticulos.show();
    sbRefrescarImporte();
    //  Call lblStatusUpdate()
    //SetTimeout(grdarticulos.refresh(),1)
    grdarticulos.refresh();

    //  MsgBox "Cargado" 
}

function resultanadirarticuloalbaran(transaction, results) {
    // Called On completion of Sql command in Function btnRead_onclick
    var x;
    dbrecords = results;
    //  grdarticulos.refresh()
    grdarticulos.hide();
    btnHistorico.show();
    btnAnadirArticulo.hide();
    grdtitulo.setValue(0, 7, "UltimoPed.");
    dblActual = 0;
    dblTotal = 0;
    for (i = 0; i <= dbrecords.rows.length - 1; i++) {
        grdarticulos.addRows(1);
        dblActual = dbrecords.rows.item(i)["PPEDIDO"] * dbrecords.rows.item(i)["PPRECIO"] * (100 - dbrecords.rows.item(i)["PDTO"]) / 100;

        dblTotal = dblTotal + dblActual;
        arrayListaAlbaran[i, 0] = "0";
        arrayListaAlbaran[i, 1] = dbrecords.rows.item(i)["CODIGOARTI"];
        arrayListaAlbaran[i, 2] = dbrecords.rows.item(i)["DESCRIPCIO"];
        arrayListaAlbaran[i, 3] = dbrecords.rows.item(i)["BULTOS"];

        arrayListaAlbaran[i, 4] = dbrecords.rows.item(i)["TARIFA"];
        arrayListaAlbaran[i, 5] = dbrecords.rows.item(i)["PRECIO"];
        arrayListaAlbaran[i, 6] = dbrecords.rows.item(i)["UNIDADES"];
        arrayListaAlbaran[i, 7] = dbrecords.rows.item(i)["ULTIMACOMPRA"];


        arrayListaAlbaran[i, 8] = dbrecords.rows.item(i)["PPEDIDO"];
        arrayListaAlbaran[i, 9] = dbrecords.rows.item(i)["PDTO"];
        if (arrayListaAlbaran[i, 9] == "") {
            arrayListaAlbaran[i, 9] = "0";
        }
        arrayListaAlbaran[i, 10] = dbrecords.rows.item(i)["PPRECIO"];
        arrayListaAlbaran[i, 11] = dbrecords.rows.item(i)["PTARIFA"];
        arrayListaAlbaran[i, 12] = dbrecords.rows.item(i)["ID"];






        grdarticulos.cell(i, 1).style.background = "transparent";
        grdarticulos.cell(i, 0).style.fontSize = "16px";
        grdarticulos.setValue(i, 0, 0);
        grdarticulos.cell(i, 0).style.textAlign = "right";
        grdarticulos.cell(i, 0).style.color = "black";

        grdarticulos.cell(i, 0).style.background = "white";
        grdarticulos.cell(i, 1).style.fontSize = "16px";
        grdarticulos.setValue(i, 1, dbrecords.rows.item(i)["CODIGOARTI"]);
        grdarticulos.cell(i, 2).style.fontSize = "16px";

        grdarticulos.setValue(i, 2, dbrecords.rows.item(i)["DESCRIPCIO"]);
        if (dbrecords.rows.item(i)["CPROMO"] > 0) {
            grdarticulos.cell(i, 2).style.color = "red";
        } else {
            grdarticulos.cell(i, 2).style.color = "black";
        }
        grdarticulos.cell(i, 3).style.fontSize = "16px";
        // If Len(dbrecords.rows.item(i)["BULTO"])>0 Then
        grdarticulos.setValue(i, 3, dbrecords.rows.item(i)["BULTOS"]);
        // ElseIf Len(dbrecords.rows.item(i)["BULTOS"])>0 Then



        grdarticulos.cell(i, 3).style.textAlign = "right";
        grdarticulos.cell(i, 4).style.fontSize = "16px";
        grdarticulos.setValue(i, 4, dbrecords.rows.item(i)["TARIFA"]);
        grdarticulos.cell(i, 4).style.textAlign = "right";
        grdarticulos.cell(i, 5).style.fontSize = "16px";
        grdarticulos.setValue(i, 5, dbrecords.rows.item(i)["PRECIO"]);
        grdarticulos.cell(i, 5).style.textAlign = "right";
        // grdarticulos.cell(i,6).style.fontSize="10px"
        //  grdarticulos.setValue(i,6,"") 'dbrecords.rows.item(i)["FECHA"])
        grdarticulos.cell(i, 6).style.fontSize = "16px";
        grdarticulos.setValue(i, 6, dbrecords.rows.item(i)["UNIDADES"]);
        grdarticulos.cell(i, 6).style.textAlign = "right";
        grdarticulos.cell(i, 7).style.fontSize = "16px";
        x = dbrecords.rows.item(i)["ULTIMACOMPRA"];
        x = Mid(x, 8, 2) + "/" + Mid(x, 5, 2) + "/" + Left(x, 4);
        grdarticulos.setValue(i, 7, x);
        grdarticulos.cell(i, 7).style.textAlign = "right";
        arrayListaAlbaran[i, 7] = x;
        if (dbrecords.rows.item(i)["PPEDIDO"] != null) {
            grdarticulos.setValue(i, 0, dbrecords.rows.item(i)["PPEDIDO"]);
            arrayListaAlbaran[i, 0] = dbrecords.rows.item(i)["PPEDIDO"];
        } else {
            grdarticulos.setValue(i, 0, "0");
            arrayListaAlbaran[i, 0] = "0";
        }
        if (dbrecords.rows.item(i)["PPEDIDO"] > 0 || dbrecords.rows.item(i)["PPEDIDO"] < 0) {
            grdarticulos.cell(i, 0).style.background = "blue";
            grdarticulos.cell(i, 0).style.color = "yellow";
        } else if (dbrecords.rows.item(i)["PPEDIDO"] == 0) {
            grdarticulos.cell(i, 0).style.background = "white";
            grdarticulos.cell(i, 0).style.color = "black";
        } else {
            grdarticulos.cell(i, 0).style.background = "blue";
            grdarticulos.cell(i, 0).style.color = "yellow";


            grdarticulos.cell(i, 0).style.textAlign = "right";


        }

        x = dbrecords.rows.item(i)["DIASULTIMACOMPRA"];

        if (x < 8) {
            grdarticulos.cell(i, 1).style.background = "lightgreen";
            grdarticulos.cell(i, 1).style.color = "black";
        } else if (x < 15) {
            grdarticulos.cell(i, 1).style.background = "green";
            grdarticulos.cell(i, 1).style.color = "black";
        } else if (x < 30) {
            grdarticulos.cell(i, 1).style.background = "darkgreen";
            grdarticulos.cell(i, 1).style.color = "white";
        } else if (x > 29) {
            grdarticulos.cell(i, 1).style.background = "brown";
            grdarticulos.cell(i, 1).style.color = "white";
        } else {
            grdarticulos.cell(i, 1).style.background = "orange";
            grdarticulos.cell(i, 1).style.color = "black";
        }

    }

    grdarticulos.show();
    // ImporteAlbaranTotal.show()
    lblAlbaranTotal.show();
    sbRefrescarImporte();
    //  SetTimeout(grdarticulos.refresh(),1)
    grdarticulos.refresh();

}

function resultanadirarticuloalbaranNOF(transaction, results) {
    // Called On completion of Sql command in Function btnRead_onclick
    var x;
    dbrecords = results;
    //  grdarticulos.refresh()
    grdarticulos.hide();
    btnHistorico.show();
    btnAnadirArticulo.hide();
    grdtitulo.setValue(0, 7, "UltimoPed.");
    dblActual = 0;
    dblTotal = 0;
    arrayListaAlbaran = createMultiDimArray(dbrecords.rows.length, 12);
    for (i = 0; i <= dbrecords.rows.length - 1; i++) {
        grdarticulos.addRows(1);
        dblActual = dbrecords.rows.item(i)["PPEDIDO"] * dbrecords.rows.item(i)["PPRECIO"] * (100 - dbrecords.rows.item(i)["PDTO"]) / 100;

        dblTotal = dblTotal + dblActual;
        arrayListaAlbaran[i, 0] = "0";
        arrayListaAlbaran[i, 1] = dbrecords.rows.item(i)["CODIGOARTI"];
        arrayListaAlbaran[i, 2] = dbrecords.rows.item(i)["DESCRIPCIO"];
        arrayListaAlbaran[i, 3] = dbrecords.rows.item(i)["BULTOS"];

        arrayListaAlbaran[i, 4] = "";
        arrayListaAlbaran[i, 5] = "";
        arrayListaAlbaran[i, 6] = "";
        arrayListaAlbaran[i, 7] = "";

        arrayListaAlbaran[i, 8] = "";

        arrayListaAlbaran[i, 9] = "0";
        arrayListaAlbaran[i, 10] = "";
        arrayListaAlbaran[i, 11] = "";
        arrayListaAlbaran[i, 12] = "";




        grdarticulos.cell(i, 0).style.fontSize = "16px";
        grdarticulos.setValue(i, 0, 0);
        grdarticulos.cell(i, 0).style.textAlign = "right";
        grdarticulos.cell(i, 0).style.color = "black";

        grdarticulos.cell(i, 0).style.background = "white";
        grdarticulos.cell(i, 1).style.fontSize = "16px";
        grdarticulos.setValue(i, 1, dbrecords.rows.item(i)["CODIGOARTI"]);
        grdarticulos.cell(i, 2).style.fontSize = "16px";
        grdarticulos.setValue(i, 2, dbrecords.rows.item(i)["DESCRIPCIO"]);
        grdarticulos.cell(i, 3).style.fontSize = "16px";
        // If Len(dbrecords.rows.item(i)["BULTO"])>0 Then
        grdarticulos.setValue(i, 3, dbrecords.rows.item(i)["BULTOS"]);
        // ElseIf Len(dbrecords.rows.item(i)["BULTOS"])>0 Then

        if (dbrecords.rows.item(i)["CPROMO"] > 0) {
            grdarticulos.cell(i, 2).style.color = "red";
        } else {
            grdarticulos.cell(i, 2).style.color = "black";
        }




        grdarticulos.setValue(i, 0, "0");

        grdarticulos.cell(i, 0).style.background = "white";



        grdarticulos.cell(i, 0).style.textAlign = "right";

    }
    grdarticulos.Width = "100%";
    //grdarticulos.setColumnWidth(0,"8%")
    //  ImporteAlbaranTotal.show()
    //lblAlbaranTotal.show()

    //grdarticulos.setColumnWidth(0,"8%")
    sbRefrescarImporte();
    // grdarticulos.colWidth="8%, 8%,35%,13%,13%,14%,10%,20%,0%,0%,0%,0%,0%"
    grdarticulos.show();
    //  SetTimeout(grdarticulos.refresh(),1)


    grdarticulos.refresh();
    // grdarticulos.refresh()
    //  Call lblStatusUpdate()
    //  SetTimeout(grdarticulos.refresh(),100)
    // SetTimeout(grdarticulos.refresh(),10)
    //  grdarticulos.refresh() 
}

frmAlbaran.onshow = function() {
    var z;
    sbMostrarPromo(false);
    // bguardaalbaran.hide()
    nsbDOMAttr(frmAlbaran, 'style.width', "100%");
    nsbDOMAttr(frmAlbaran, 'style.height', "100%");

    grdtitulo.setValue(0, 0, "P");
    grdtitulo.setValue(0, 1, "Codigo");
    grdtitulo.setValue(0, 2, "Artículo");
    grdtitulo.setValue(0, 3, "Uc");
    grdtitulo.setValue(0, 4, "Ta");
    grdtitulo.setValue(0, 5, "€U");
    grdtitulo.setValue(0, 6, "Ud");
    grdtitulo.setValue(0, 7, "UltimoPed.");
    for (z = 0; z <= 7; z++) {
        grdtitulo.cell(0, z).style.background = "black";
        grdtitulo.cell(0, z).style.color = "yellow";
    }

    gstrorder = " order by CAST (DIASULTIMACOMPRA AS INTEGER) asc ";
    //grdtitulo.style.width = (window.innerWidth - 8)
    //grdarticulos.style.width = (window.innerWidth - 8)
    //grdarticulos.refresh()
    //grdtitulo.refresh()


    //TitleBar1.style.top=0


    //strEstadoAnadir="Historico"
    currentrow = -1;
    blnAlbaranEditado = 0;
    //bguardaalbaran.hide()


    sbInicializarDatosArticulo();
    strObservaciones = "";
    //txtObservaciones.hide()

    bBuscar.hide();
    currentrow = -1;
    if (strEstadoAnadir == "Pedido") {
        sbcargahistorico(" PPEDIDO<>0 ");
    } else if (strEstadoAnadir == "Historico") {
        sbcargahistorico("");
    }
    sbRefrescarImporte();

};

grdarticulos.onclick = function() {
    var nohistorico;
    var lineaclick;
    sbMostrarPromo(false);
    txtPromoCodigo.value = "";
    //SetTimeout(grdarticulos.refresh(),100)
    if (grdarticulos.getRowCount() == 0) {
        return;
    }
    s = Split(event.target.id, "_");
    lineaclick = s[1];

    if (currentrow == lineaclick) {
        return;
    }
    nohistorico = 0;
    if (Len(arrayListaAlbaran[lineaclick, 4]) == "null" || arrayListaAlbaran[lineaclick, 4] == "undefined") {
        nohistorico = 1;

    } else if (Len(arrayListaAlbaran[lineaclick, 4]) == 0) {
        nohistorico = 1;
    }
    txtDto.value = 0;
    txtcodigoarticuloalbaran.value = arrayListaAlbaran[lineaclick, 1];

    txtnombrearticuloalbaran.value = arrayListaAlbaran[lineaclick, 2];
    intUnidadesCaja = arrayListaAlbaran[lineaclick, 3];
    txtCajas.value = 0;
    txtDto.value = arrayListaAlbaran[lineaclick, 9];
    txtUnidades.value = _jsCint(arrayListaAlbaran[lineaclick, 0]);
    if (txtUnidades.value == "0" && btnHistorico.Visible == false) {
        txtUnidades.value = _jsCint(arrayListaAlbaran[lineaclick, 6]);

    }
    txtPrecio.value = arrayListaAlbaran[lineaclick, 5];
    if (nohistorico == 1) {
        txtTarifa.value = txtTarifaCliente.value;

    } else {

        txtTarifa.value = arrayListaAlbaran[lineaclick, 4];
    }
    if (txtSerie.value == "55") {
        txtTarifa.value = 55;
    }

    sbActualizaRow(lineaclick);
    if (tar.value() == "Off") {
        grdtarifaalbaran.Visible = true;
    }

    sbCalculaTotal();

    sbCargaArticulo.onclick;
    sbCargaArticulo();
    if (txtSerie == "55") {
        txtTarifa.value = "55";

    }
    sbcargaTarifa(txtcodigoarticuloalbaran.value);

    sbabrirteclado();
    if (btnHistorico.hidden == true && btnAnadirArticulo.hidden == false) {
        bGuardar.show();
        bBorra.show();

    } else if (btnHistorico.hidden == false && btnAnadirArticulo.hidden == true) {
        bGuardar.show();
        bBorra.show();
    } else {
        // bGuardar.hide()
    }

};

function mm() {
    switch (true) {

        case ((VAL(choice)) == 4):
            // frmPrincipal.txtcodigoclientealbaran.value=txtcodigo.value
            //frmAlbaran.txtnombreclientealbaran=txtnombrecliente.value
            frmPrincipal.style.webkitTransitionDuration = "1ms"; //take 1 second to do this.
            frmPrincipal.style.webkitTransform = "translateX(-" + SysInfo(0) + "px)"; //slide left
            //Wait for the transition to complete half way before starting form2
            // SetTimeout(frmprincipaltoshow,10)
    }

}









grdtitulo.onclick = function() {
    var x;
    var strclave;
    var miorder;
    s = Split(event.target.id, "_");

    // MsgBox  "Click on " & s(0) & " at row " & s(1) & " and column " & s(2)
    x = s[2];
    switch (true) {
        case ((x) == 0):
            strclave = "PPEDIDO";
            break;
        case ((x) == 2):
            strclave = "DESCRIPCIO";
            break;
        case ((x) == 1):
            strclave = "CODIGOARTI";
            break;
        case ((x) == 7):
            strclave = "CAST (DIASULTIMACOMPRA AS INTEGER) ";
            //  Case 7:
            //   strclave="UNIDADESPERIODO"    
            break;
        default:
            return;
    }
    miorder = " order by " + strclave + " asc";
    if (gstrorder == " order by " + strclave + " asc") {
        gstrorder = " order by " + strclave + " desc";
    } else if (gstrorder == " order by " + strclave + " desc") {
        gstrorder = " order by " + strclave + " asc";
    } else {
        gstrorder = " order by " + strclave + " asc";
    }
    sbcargahistorico()("");
    //txtPrecio.value=grdtarifasalbaran.getValue(s(1),1)
};

function resultrecuperarid(transaction, results) {

    var strAux;

    dbrecords = results;

    NSB.WaitCursor(false);






    strAux = dbrecords.rows.item(0)["ID"];

    //grdarticulos.setValue(currentrow, 12,strAux  )
    arrayListaAlbaran[currentrow, 12] = strAux;


    if (txtDto.value == "") {
        txtDto.value = "0";
    }
    misql = "Update FRECUENC set PPEDIDO='" + txtTotal.value + "',";
    misql = misql + " PDTO='" + txtDto.value + "', ";
    misql = misql + " PTARIFA='" + txtTarifa.value + "',";
    misql = misql + " PPRECIO='" + txtPrecio.value + "'";
    // misql=misql & ", '" & txtPrecio.value & "'"
    misql = misql + " where ID='" + arrayListaAlbaran[currentrow, 12] + "';";
    sqlList = [];
    sqlList[0] = misql;
    Sql(DB, sqlList);

    grdarticulos.setValue(currentrow, 0, txtTotal.value);

    arrayListaAlbaran[currentrow, 10] = txtPrecio.value;
    if (txtDto.value == "") {
        txtDto.value = "0";
    }
    arrayListaAlbaran[currentrow, 9] = txtDto.value;

    arrayListaAlbaran[currentrow, 0] = txtTotal.value;
    arrayListaAlbaran[currentrow, 11] = txtTarifa.value;
    if (txtTotal.value != 0) {
        grdarticulos.cell(currentrow, 0).style.background = "blue";
        grdarticulos.cell(currentrow, 0).style.color = "yellow";
    } else {
        grdarticulos.cell(currentrow, 0).style.background = "white";
        grdarticulos.cell(currentrow, 0).style.color = "black";
    }

    sbabrirteclado();
    sbRefrescarImporte();

}

function resultarifasalbaran(transaction, results) {
    var strAux;
    var j, k;
    dbrecords = results;

    // j= VAL(menu.selectedValue())
    //********************************************************************************************
    NSB.WaitCursor(false);
    //MsgBox "" &  VAL(menu.selectedValue())

    i = 0;
    grdtarifaalbaran.disabled = false;
    grdtarifaalbaran.deleteRows(30);
    noeshistorico = 0;
    if (Len(arrayListaAlbaran[currentrow, 4]) == 0) {
        noeshistorico = 1;
    }

    //     For j=0 To 20
    // grdtarifas.getRowCount()>0
    grdtarifaalbaran.deleteRows(grdtarifaalbaran.getRowCount() - 1);
    //  Next

    for (k = 0; k <= dbrecords.rows.length - 1; k++) {
        grdtarifaalbaran.addRows(1);
        // grtarifak.
        if (noeshistorico == 1) {
            //   MsgBox "" &  straux & " , " & txtTarifaCliente.value
            if (dbrecords.rows.item(k)["mitarifa"] == txtTarifaCliente.value || dbrecords.rows.item(k)["mitarifa"] == strTarifaClienteActual) {
                txtPrecio.value = dbrecords.rows.item(k)["miprecio"];
                txtTarifa.value = dbrecords.rows.item(k)["mitarifa"];
            }
        }
        strAux = dbrecords.rows.item(k)["CPROMO"];
        if (strAux == 0) {
            grdtarifaalbaran.setValue(k + 1, 2, "");
            grdtarifaalbaran.cell(k + 1, 0).style.background = "transparent";
            grdtarifaalbaran.cell(k + 1, 0).style.color = "black";
            grdtarifaalbaran.cell(k + 1, 1).style.background = "transparent";
            grdtarifaalbaran.cell(k + 1, 1).style.color = "black";
            grdtarifaalbaran.cell(k + 1, 2).style.background = "transparent";
            grdtarifaalbaran.cell(k + 1, 2).style.color = "transparent";
        } else {
            grdtarifaalbaran.setValue(k + 1, 2, strAux);
            grdtarifaalbaran.cell(k + 1, 0).style.background = "red";
            grdtarifaalbaran.cell(k + 1, 0).style.color = "white";
            grdtarifaalbaran.cell(k + 1, 1).style.background = "red";
            grdtarifaalbaran.cell(k + 1, 1).style.color = "white";
            grdtarifaalbaran.cell(k + 1, 2).style.background = "transparent";
            grdtarifaalbaran.cell(k + 1, 2).style.color = "transparent";
        }

        strAux = dbrecords.rows.item(k)["mitarifa"];

        grdtarifaalbaran.setValue(k + 1, 0, strAux);
        strAux = dbrecords.rows.item(k)["miprecio"];
        //MsgBox "" &   txtSerie.value & " " & dbrecords.rows.item(k)["mitarifa"]
        if (txtSerie.value == "55" && dbrecords.rows.item(k)["mitarifa"] == "55") {
            txtPrecio.value = dbrecords.rows.item(k)["miprecio"];
        }
        grdtarifaalbaran.setValue(k + 1, 1, strAux);
    }

    grdtarifaalbaran.disabled = false;



}

function sbcargaTarifa(codigoarti) {
    var j;

    grdtarifaalbaran.deleteRows(grdtarifaalbaran.getRowCount);

    sqlList = [];
    sqlList[0] = ["SELECT  CODIGOTARI as mitarifa, PRECIO as miprecio, CPROMO from ATARIFAS where CODIGOARTI = '" + codigoarti + "' " + filtrotarifa + " ;", resultarifasalbaran];


    Sql(DB, sqlList);


}

function sbabrirteclado() {
    if (currentrow == -1) {

        bGuardar.Visible = false;
        bBorra.hide();
        lblUds.Visible = false;
        lblCajas.Visible = false;
        lblTotal.Visible = false;
        txtUnidades.Visible = false;
        txtCajas.Visible = false;
        txtTotal.Visible = false;
        txtTarifa.Visible = false;
        txtPrecio.Visible = false;
        txtDto.Visible = false;
        lblTarifa.Visible = false;
        lblDto.Visible = false;
        lblPrecio.Visible = false;
        lblUC.Visible = false;
        lblUC.textContent = "";
        blnTecladoSucio = 0;



    } else {

        bGuardar.Visible = true;
        bBorra.show();
        lblUds.Visible = true;
        lblCajas.Visible = true;
        lblTotal.Visible = true;
        txtUnidades.Visible = true;
        txtCajas.Visible = true;
        txtTotal.Visible = true;
        txtTarifa.Visible = true;
        txtPrecio.Visible = true;
        txtDto.Visible = true;
        lblTarifa.Visible = true;
        lblDto.Visible = true;
        lblPrecio.Visible = true;
        lblUC.Visible = true;
        lblUC.textContent = intUnidadesCaja;
        blnTecladoSucio = 0;


    }

}





function sbCalculaTotal() {
    var Inttotal;

    // MsgBox "" &  grdteclado.getValue(0 , 4) & " / " &  grdteclado.getValue(1 , 4) & " / " & intUnidadesCaja
    Inttotal = _jsCint(txtUnidades.value) + _jsCint(txtCajas.value) * _jsCint(intUnidadesCaja);
    txtTotal.value = Inttotal;
    if (Inttotal > 0) {
        bGuardar.show();
        bBorra.show();

    } else if (Inttotal < 0) {
        //MsgBox  "No seNegativo"
    }


    if (txtTotal.value == "") {
        txtTotal.value = "0";
    }
}









bGuardar.onclick = function() {
    var misql;
    if (txtDto.value == "") {
        txtDto.value = "0";
    }

    if (txtUnidades.value == "" || txtCajas.value == "" || txtPrecio.value == "" || txtTarifa.value == "") {
        NSB.MsgBox("Datos Incompletos");
        return;
    }

    if (_jsCint(txtTotal.value) < 0) {
        NSB.MsgBox("No se permiten cantidades negativas. Linea de Albaran NO GUARDADA");
        return;
    }

    blnAlbaranEditado = 1;
    //bguardaalbaran.show()

    if (txtUnidades.value == "") {
        txtUnidades.value = 0;
    }
    if (txtCajas.value == "") {
        txtCajas.value = 0;
    }
    if (txtPrecio.value == "") {
        txtPrecio.value = "0";
    }
    sbCalculaTotal();
    //TitleBarAlbaran.item(0).Visible=0
    //***********************************************************
    //***********************************************************
    //MsgBox "" & btnAnadirArticulo.hidden & " / " &   btnHistorico.hidden
    if (arrayListaAlbaran[currentrow, 12] == "undefined" || arrayListaAlbaran[currentrow, 12] == "") {
        //MsgBox  btnAnadirArticulo.hidden & " / " &   btnHistorico.hidden    


        misql = "Insert into FRECUENC (CODIGOARTI, PPEDIDO, PDTO, PTARIFA, PPRECIO, CODIGOCLIE, DESCRIPCIO, BULTOS, CODIGOCOMISIONISTA)  values ('" + arrayListaAlbaran[currentrow, 1] + "',  '" + txtTotal.value + "', '" + txtDto.value + "', '" + txtTarifa.value + "', '" + txtPrecio.value + "',  '" + txtcodigoclientealbaran.value + "', '" + arrayListaAlbaran[currentrow, 2] + "','" + arrayListaAlbaran[currentrow, 3] + "', '" + _jsCint(localStorage.comercial) + "') ";

        sqlList = [];
        sqlList[0] = misql;
        //  MsgBox "" & misql
        Sql(DB, sqlList);
        // misql = >"Select id from FRECUENC order by ID desc limit 2;", resultanadirarticuloalbaran
        sqlList = [];

        sqlList[0] = ["Select id from FRECUENC where codigoarti='" + arrayListaAlbaran[currentrow, 1] + "' order by ID desc limit 1;", resultrecuperarid];

        //Select * FROM table_name_1 Left OUTER Join table_name_2 On id_1 = id_2



        Sql(DB, sqlList);

    } else {
        misql = "Update FRECUENC set PPEDIDO='" + txtTotal.value + "',";
        misql = misql + " PDTO='" + txtDto.value + "', ";
        misql = misql + " PTARIFA='" + txtTarifa.value + "',";
        misql = misql + " PPRECIO='" + txtPrecio.value + "'";

        // misql=misql & ", '" & txtPrecio.value & "'"
        misql = misql + " where ID='" + arrayListaAlbaran[currentrow, 12] + "';";
        sqlList = [];
        sqlList[0] = misql;
        Sql(DB, sqlList);

        arrayListaAlbaran[currentrow, 10] = txtPrecio.value;
        arrayListaAlbaran[currentrow, 9] = txtDto.value;
        arrayListaAlbaran[currentrow, 0] = txtTotal.value;
        arrayListaAlbaran[currentrow, 11] = txtTarifa.value;

        grdarticulos.setValue(currentrow, 0, txtTotal.value);

        if (txtTotal.value != 0) {
            grdarticulos.cell(currentrow, 0).style.background = "blue";
            grdarticulos.cell(currentrow, 0).style.color = "yellow";
        } else {
            grdarticulos.cell(currentrow, 0).style.background = "white";
            grdarticulos.cell(currentrow, 0).style.color = "black";
        }

        sbabrirteclado();
        bGuardar.onclick();


    }
    sbGuardaAlbaran();
    sbRefrescarImporte();

    txtnombrearticuloalbaran.value = "";
    txtcodigoarticuloalbaran.value = "";
};

txtCajas.onchange = function() {
    //  sbCalculaTotal
};

txtPrecio.onchange = function() {
    //  sbCalculaTotal
};




btnHistorico.onclick = function() {
    //ImporteAlbaranTotal.hide()
    //  lblAlbaranTotal.hide()
    if (strEstadoAnadir == "Historico") {
        return;
    }
    currentrow = -1;
    txtPromoCodigo.value = "";
    sbActualizaRow();
    sbInicializarDatosArticulo();
    bBuscar.hide();
    // bGuardar.hide()
    txtnombrearticuloalbaran.style.backgroundColor = "transparent";
    txtcodigoarticuloalbaran.style.backgroundColor = "transparent";
    txtnombrearticuloalbaran.placeholder = "";
    txtcodigoarticuloalbaran.placeholder = "";
    sbBorraGridArticulos();
    strEstadoAnadir = "Historico";
    sbcargahistorico("");
    btnAnadirArticulo.show();
    btnHistorico.hide();
};


function sbActualizaRowACero(v) {


    // MsgBox " no menos 1"
    for (z = 2; z <= 7; z++) {
        grdarticulos.cell(currentrow, v).style.background = "transparent";


    }


}

function sbActualizaRow(v) {
    txtPromoCodigo.value = "";
    if (currentrow == -1 && v == -1) {
        grdtarifaalbaran.hide();

        return;
    }
    //MsgBox " x es " & v & " / " & currentrow
    if (currentrow == -1) {
        grdtarifaalbaran.hide();
        // MsgBox " menos 1"
        for (z = 2; z <= 7; z++) {
            grdarticulos.cell(v, z).style.background = "yellow";


        }
    }

    if (currentrow != -1) {
        // MsgBox " no menos 1"
        for (z = 2; z <= 7; z++) {
            grdarticulos.cell(currentrow, z).style.background = "transparent";
            grdarticulos.cell(v, z).style.background = "yellow";

        }
    }
    currentrow = v;
}

bBorra.onclick = function() {
    blnAlbaranEditado = 1;
    //bguardaalbaran.hide()
    txtCajas.value = 0;
    txtUnidades.value = 0;
    txtTotal.value = 0;
    bGuardar.onclick();
    sbRefrescarImporte();
};




txtCajas.onfocus = function() {
    txtCajas.value = "";
};

txtPrecio.onfocus = function() {
    txtPrecio.value = "";
};









bBuscar.onclick = function() {
    window.blur();
    sbBorraGridArticulos();
    sbcargaarticulos();

};

function sbcargaarticulos() {
    var strAux;
    var strOrigen;
    var strAuxCodigo;
    strAux = "";
    strOrigen = txtnombrearticuloalbaran.value;
    //  JavaScript
    // $("#List1").empty()
    //End JavaScript
    List1.deleteItem("All");
    if ((txtcodigoarticuloalbaran.value == "" && txtnombrearticuloalbaran.value == "") && flipPromo.value == "Ver Todos") {

        return;
    }
    strAuxCodigo = "  articulo.CODIGOARTI like '" + txtcodigoarticuloalbaran.value + "%' ";
    if (Len(txtnombrearticuloalbaran.value) == 99999 && Math.floor(txtcodigoarticuloalbaran.value) > 0) {

        strAux = " "; // articulo.CODIGOARTI like '" & strOrigen & "%'"
        strAuxCodigo = " "; // articulo.CODIGOARTI like '" & strOrigen & "%'"


    } else {
        strAux = strOrigen.indexOf(' ');

        var n = strOrigen.split(' ');
        strAux = ' (articulo.descripcio like "%' + n[0] + '%" ) '

        for (i = 1; i < n.length; i++) {
            strAux = strAux + ' and (articulo.DESCRIPCIO like "%' + n[i] + '%") '

        }

        strAuxCodigo = " articulo.CODIGOARTI like '" + txtcodigoarticuloalbaran.value + "%' ";

        if (txtnombrearticuloalbaran.value == "") {
            strAux = strAuxCodigo;
        }
        if (txtcodigoarticuloalbaran.value == "") {
            strAuxCodigo = " 1=1 ";
        }



    }
    sqlList = [];
    switch (true) {
        case ((txtSerie.value) == "CA"):
            strAux = filtroCA + strAux;
            break;
        case ((txtSerie.value) == "55"):
            strAux = filtro55 + strAux;

            break;
        default:
            strAux = " 1=1 and " + strAux;
    }
    var auxpromo;
    auxpromo = flipPromo.value;



    if (auxpromo != "Ver Todos") {

        strAux = strAux + iif(Right(RTrim(strAux), 3) == "and", " ", " and ") + " articulo.CPROMO>0 ";
    }

    sqlList[0] = ["SELECT  articulo.BULTOS as BULTO, articulo.*,  NULL as FECHA, NULL as TARIFA, NULL as UNIDADES, NULL as ULTIMACOMPRA, NULL as DIASULTIMACOMPRA, NULL as PPEDIDO, NULL as PDTO, NULL AS ID  from ARTICULO WHERE  " + strAux + "   ORDER BY  articulo.DESCRIPCIO   limit 800;", resultanadirarticuloalbaranNOF];

    //Select * FROM table_name_1 Left OUTER Join table_name_2 On id_1 = id_2



    Sql(DB, sqlList);


}
btnAnadirArticulo.onclick = function() {

    if (strEstadoAnadir == "Articulo") {
        return;
    }
    currentrow = -1;
    txtPromoCodigo.value = "";
    sbActualizaRow();

    strEstadoAnadir = "Articulo";
    bBuscar.show();

    sbBorraGridArticulos();
    btnAnadirArticulo.hide();
    btnHistorico.show();
    txtnombrearticuloalbaran.style.backgroundColor = "white";
    txtcodigoarticuloalbaran.style.backgroundColor = "white";
    txtcodigoarticuloalbaran.value = "";
    txtnombrearticuloalbaran.value = "";
    txtnombrearticuloalbaran.placeholder = "Nombre de Articulo";
    txtcodigoarticuloalbaran.placeholder = "Familia";
    //grdarticulos.hide()
    btnAnadirArticulo.hide();
    btnHistorico.show();


    sbInicializarDatosArticulo();

    sbRefrescarImporte();


};

function sbCargaArticulo() {
    var intunidades;
    var txtarti;

    sbabrirteclado();

    return;
    txtarti = txtnombrearticuloalbaran.value;
    intunidades = prompt("Unidades:", "");
    grdarticulos.setValue(s[1], 0, intunidades);
    arrayListaAlbaran[s(1), 0] = intunidades;
    if (intunidades != 0) {
        grdarticulos.cell(s[1], 0).style.background = "blue";
        grdarticulos.cell(s[1], 0).style.color = "yellow";
    } else {
        grdarticulos.cell(s[1], 0).style.background = "transparent";
        grdarticulos.cell(i, 0).style.color = "black";

    }
    txtCajas.value = 0;
    txtCajas.Visible = true;
    txtUnidades.value = 0;
    txtUnidades.Visible = true;

    txtTarifa.value = arrayListaAlbaran[currentrow, 11];
    txtPrecio.value = arrayListaAlbaran[currentrow, 10];
    txtDto.value = arrayListaAlbaran[currentrow, 9];
    txtTotal.value = arrayListaAlbaran[currentrow, 0];
    txtUnidades.value = arrayListaAlbaran[currentrow, 0];
}




bPedido.onclick = function() {
    if (strEstadoAnadir == "Pedido") {
        return;
    }

    currentrow = -1;
    txtPromoCodigo.value = "";
    sbActualizaRow();
    grdtarifaalbaran.hide();
    // For i=0 To grdarticulos.getRowCount() -1
    sbBorraGridArticulos();
    //  Next

    //  sbInicializarDatosArticulo
    bBuscar.hide();
    btnHistorico.show();
    btnAnadirArticulo.show();
    bGuardar.show();
    bBorra.show();
    txtnombrearticuloalbaran.style.backgroundColor = "transparent";
    txtcodigoarticuloalbaran.style.backgroundColor = "transparent";
    txtnombrearticuloalbaran.placeholder = "";
    txtcodigoarticuloalbaran.placeholder = "";


    strEstadoAnadir = "Pedido";

    sbcargahistorico(" PPEDIDO<>0 ");
    btnHistorico.Visible = true;

};






txtnombrearticuloalbaran.onclick = function() {
    if (txtnombrearticuloalbaran.style.backgroundColor == "white") {
        //  If  btnHistorico.hidden =False And btnAnadirArticulo.hidden=True Then
        txtnombrearticuloalbaran.value = "";
        txtcodigoarticuloalbaran.value = "";
    }
    //End If  
};

txtcodigoarticuloalbaran.onclick = function() {
    if (txtnombrearticuloalbaran.style.backgroundColor == "white") {
        //  If  btnHistorico.hidden =False And btnAnadirArticulo.hidden=True Then
        txtnombrearticuloalbaran.value = "";
        txtcodigoarticuloalbaran.value = "";
    }
};


function resultguardaalbaran(transaction, results) {

    var strAux;
    var dblTotal, dblIVA;
    var j, k;
    var numlineas;
    dbrecords = results;
    NSB.WaitCursor(false);
    dblTotal = 0;
    dblIVA = 0;
    sbRefrescarImporte();
    sqlList = [];
    numlineas = dbrecords.rows.length;
    for (k = 0; k <= dbrecords.rows.length - 1; k++) {
        // dblTotal=dblTotal + dbrecords.rows.item(k)["PPEDIDO"] * dbrecords.rows.item(k)["PPRECIO"] * (100- dbrecords.rows.item(k)["PDTO"])/100 

        sqlList[k] = "Insert into ALBARANL (CALBARAN , IVA, CODIGOLINE , CODIGOARTI , UNIDADES , PRECIO , DCTO  , TARIFA , CODIGOCOMISIONISTA, ID) ";
        sqlList[k] = sqlList[k] + "VALUES (" + txtNumeroAlbaran.value + ", " + dbrecords.rows.item(k)["IVA"] + ", " + k + ",  '" + dbrecords.rows.item(k)["CODIGOARTI"] + "', " + dbrecords.rows.item(k)["PPEDIDO"] + ", " + dbrecords.rows.item(k)["PPRECIO"] + ", " + dbrecords.rows.item(k)["PDTO"] + ",";
        sqlList[k] = sqlList[k] + "" + dbrecords.rows.item(k)["PTARIFA"] + ", '" + localStorage.comercial + "'," + dbrecords.rows.item(k)["ID"] + ");";

        dblTotal = dblTotal + dbrecords.rows.item(k)["PPEDIDO"] * dbrecords.rows.item(k)["PPRECIO"] * (100 - dbrecords.rows.item(k)["PDTO"]) / 100;

        dblIVA = dblIVA + dbrecords.rows.item(k)["PPEDIDO"] * dbrecords.rows.item(k)["PPRECIO"] * dbrecords.rows.item(k)["IVA"] / 100 * (100 - dbrecords.rows.item(k)["PDTO"]) / 100;


        // dblIVA=dbrecords.rows.item(0)["TOTALALBARAN"] 

        //ImporteAlbaranTotal.value= Round(dblTotal,2)
        // ImporteAlbaranTotalIVA.value= Round(dblIVA,2)

        //ImporteAlbaranTotalAlbaran.value=Round(Round(dblIVA,2)+Round(dblTotal,2),2)


    }
    k = dbrecords.rows.length;
    //'CODIGOARTI' TEXT , 'UNIDADES' TEXT , 'PRECIO' REAL , 'DCTO' TEXT , 'COMPRAS' TEXT , 'FECHA' TEXT , 'TARIFA' REAL , 'CODIGOCLIE' TEXT , 'BULTOS' TEXT , 'DESCRIPCIO' TEXT , 'CODIGOCOMISIONISTA' TEXT , 'ULTIMACOMPRA' TEXT , 'ULTIMOPRECIO' TEXT , 'DIASULTIMACOMPRA' TEXT , 'ULTIMAUNIDAD' TEXT , 'UNIDADESPERIODO' TEXT , 'PEDIDO' REAL , 'PPRECIO' REAL , 'PTARIFA' TEXT , 'ID'  INTEGER PRIMARY KEY , 'PPEDIDO' REAL , 'PDTO' REAL )
    dblTotal = Round(Round(dblTotal, 2) + Round(dblIVA, 2), 2);
    sqlList[k] = "Insert into ALBARAN (CALBARAN, FECHA , HORA, CCLIENTE , OBS , IMPORTE , SERIE ,CodigoComisionista, TRANSMITIDO, CAPTURA) ";
    sqlList[k] = sqlList[k] + " VALUES (" + txtNumeroAlbaran.value + " , '" + FormatDateTime(DateAdd("s", 0, new Date()), 10) + "', '" + Hour(DateAdd("s", 0, new Date())) + ":" + _vbsString(2 - Len(Minute(DateAdd("s", 0, new Date()))), "0") + Minute(DateAdd("s", 0, new Date())) + "', '" + txtcodigoclientealbaran.value + "', '" + txtObservaciones.value + "', " + dblTotal + ", '" + txtSerie.value + "', '" + localStorage.comercial + "', 0," + numlineas + ");";
    Sql(DB, sqlList);
    if (blnNuevoAlbaran == 1) {
        localStorage.intUltimoAlbaran = txtNumeroAlbaran.value;
    }
    blnAlbaranEditado = 0;
    // bguardaalbaran.hide()

    fnUltimoAlbaran();

    //' MsgBox "Albaran número " & txtNumeroAlbaran.value & " Guardado"
    // grtarifak.
}
txtCajas.onblur = function() {
    txtUnidades.value = "0";
    sbCalculaTotal();
};

function sbInicializarDatosArticulo() {
    txtUnidades.value = 0;
    txtCajas.value = 0;
    txtPrecio.value = 0;
    txtTotal.value = 0;
    txtDto.value = 0;
    lblUC.textContent = "";

    txtDto.value = 0;


    txtnombrearticuloalbaran.value = "";
    txtcodigoarticuloalbaran.value = "";
    if (strEstadoAnadir == "Historico") {
        btnHistorico.hide();
        bPedido.show();
        btnAnadirArticulo.show();
    } else if (strEstadoAnadir == "Pedido") {
        btnHistorico.show();
        bPedido.hide();
        btnAnadirArticulo.show();
    } else {
        btnHistorico.show();
        bPedido.show();
        btnAnadirArticulo.hide();
    }
    sbabrirteclado();
}




txtUnidades.onblur = function() {

    sbCalculaTotal();
};

txtUnidades.onclick = function() {
    bGuardar.show();
    bBorra.show();
    txtUnidades.value = "";
};



txtnombrearticuloalbaran.onblur = function() {
    bBuscar.show();

};

txtcodigoarticuloalbaran.onblur = function() {
    bBuscar.show();
};

txtUnidades.onchange = function() {
    bGuardar.show();
    bBorra.show();
};

function sbBorraGridArticulos() {
    var k;
    if (grdarticulos.getRowCount() > 1) {
        // grdarticulos.hide()
        if (currentrow != -1) {
            k = currentrow;
            currentrow = -1;
            sbActualizaRow(k);


        }

        //  For i=0 To grdarticulos.getRowCount()
        grdarticulos.deleteRows(grdarticulos.getRowCount() - 1);
        for (k = 0; k <= grdarticulos.getColCount() - 1; k++) {
            grdarticulos.setValue(0, k, "");
            grdarticulos.cell(0, k).style.background = "transparent";
        }
        grdarticulos.refresh();
        currentrow = -1;
    } else {
        for (k = 0; k <= grdarticulos.getColCount() - 1; k++) {
            grdarticulos.setValue(0, k, "");
        }
        currentrow = -1;
    }
}
txtCajas.onclick = function() {
    bGuardar.show();
    bBorra.show();

    txtCajas.value = "";
};

function sbRefrescarImporte() {
    sqlList = [];
    sqlList[0] = ["SELECT  sum(PPEDIDO *  PPRECIO * (100-PDTO)/100 ) as TOTAL, sum(PPEDIDO *  PPRECIO * iva /100 * (100-PDTO)/100 ) as TOTALALBARAN from frecuenc inner join articulo on (frecuenc.codigoarti=articulo.codigoarti);", resultimporte];
    Sql(DB, sqlList);



}

function sbRefrescarLineas() {
    sqlList = [];
    sqlList[0] = ["SELECT  count (PPEdido) as cuenta from frecuenc where ppedido<>0 and CODIGOCLIE='" + txtcodigoclientealbaran.value + "';", resultcuentalineas];
    Sql(DB, sqlList);



}

function resultimporte(transaction, results) {




    var dblTotal, dblIVA;
    var k;

    dbrecords = results;

    NSB.WaitCursor(false);
    dblTotal = 0;
    dblIVA = 0;




    dblTotal = dbrecords.rows.item(0)["TOTAL"];
    dblIVA = dbrecords.rows.item(0)["TOTALALBARAN"];

    ImporteAlbaranTotal.value = Round(dblTotal, 2);
    ImporteAlbaranTotalIVA.value = Round(dblIVA, 2);

    ImporteAlbaranTotalAlbaran.value = Round(Round(dblIVA, 2) + Round(dblTotal, 2), 2);
    sbRefrescarLineas();
}

function resultcuentalineas(transaction, results) {





    var k;

    dbrecords = results;

    NSB.WaitCursor(false);
    k = 0;



    k = dbrecords.rows.item(0)["cuenta"];
    txtLineas.value = k;
}



grdtarifaalbaran.ontouchstart = function() {

};

Button1.onclick = function() {

    if (blnAlbaranEditado == 1) {
        NSB.MsgBox("Debe guardar los cambios en observaciones antes de guardar");
        return;
    }

    continue1 = 1; // MsgBox ("¿Desea salir?",1)
    if (continue1 == 1) {


        misql = "Update FRECUENC set PPEDIDO=0,";
        misql = misql + " PDTO=0, ";
        misql = misql + " PTARIFA=0, ";
        misql = misql + " PPRECIO=0";
        sqlList = [];
        sqlList[0] = misql;
        Sql(DB, sqlList);
        // misql=misql & ", '" & txtPrecio.value & "'"




        txtcodigoclientealbaran.value = "";
        txtnombrearticuloalbaran.value = "";
        txtObservaciones.value = "";
        //Wait for the transition to complete half way before starting form2
        // Setº(frmprincipalto,100)
        flipPromo.value = "Ver Todos";
        sbBorraGridArticulos();

        //frmAlbaran.hide()
        // frmPrincipal.reset()
        // CreateButton()
        ChangeForm(frmPrincipal);
        //    Call
    }
};






function sbContinuarGrabando() {
    sqlList = [];
    sqlList[0] = ["SELECT FRECUENC.*, ARTICULO.IVA from frecuenc, ARTICULO WHERE FRECUENC.CODIGOARTI = ARTICULO.CODIGOARTI AND FRECUENC.PPEDIDO<>0 order by FRECUENC.codigoarti;", resultguardaalbaran];
    Sql(DB, sqlList);
}
Button3.onclick = function() {
    continue1 = NSB.MsgBox("¿Desea elimianr el albaran?", 1);
    if (continue1 == 1) {

        sqlList = [];
        sqlList[0] = ["Delete from ALBARANL where calbaran=" + txtNumeroAlbaran.value + ";"];
        //
        sqlList[1] = ["Delete from ALBARAN where calbaran=" + txtNumeroAlbaran.value + ";"];



        sqlList[2] = ["Update FRECUENC SET PPEDIDO=0, pprecio=0, PTARIFA=0, PDTO=0 "];

        Sql(DB, sqlList);

        sbBorraGridArticulos();

        blnAlbaranEditado = 0;
        //bguardaalbaran.hide()

        txtcodigoclientealbaran.value = "";
        txtnombrearticuloalbaran.value = "";

        //Wait for the transition to complete half way before starting form2
        // Setº(frmprincipalto,100)



        //frmAlbaran.hide()
        // frmPrincipal.reset()
        // CreateButton()
        fnUltimoAlbaran();
        ChangeForm(frmPrincipal);
        //    Call

    }

};

txtObservaciones.onblur = function() {
    blnAlbaranEditado = 1;
    // bguardaalbaran.show()

};

tar.onchange = function() {
    if (tar.value() == "On") {
        grdtarifaalbaran.hide();
    } else {
        grdtarifaalbaran.show();
    }
};

txtObservaciones.ongestureend = function() {

};

grdtarifaalbaran.onfocus = function() {

};

frmAlbaran.onhide = function() {

};




function sbGuardaAlbaran() {

    if (blnAlbaranEditado == 0) {
        return;
    }
    //  If txtLineas.value=0 Then Exit Sub
    // '   MsgBox "No se puede guardar un albaran sin lineas"
    //   Exit Sub
    //   End If
    //sbRefrescarImporte

    sqlList = [];
    sqlList[0] = ["Delete from ALBARANL where calbaran=" + txtNumeroAlbaran.value + ";"];

    sqlList[1] = ["Delete from ALBARAN where calbaran=" + txtNumeroAlbaran.value + ";"];

    Sql(DB, sqlList);
    sbContinuarGrabando();


}

txtObservaciones.onchange = function() {
    blnAlbaranEditado = 1;
};

txtDto.onclick = function() {
    txtDto.value = "";

};

function flipPromoonchange() {
    if (strEstadoAnadir == "Historico") {
        currentrow = -1;
        sbActualizaRow();
        sbInicializarDatosArticulo();
        bBuscar.hide();
        // bGuardar.hide()
        txtnombrearticuloalbaran.style.backgroundColor = "transparent";
        txtcodigoarticuloalbaran.style.backgroundColor = "transparent";
        txtnombrearticuloalbaran.placeholder = "";
        txtcodigoarticuloalbaran.placeholder = "";
        sbBorraGridArticulos();
        strEstadoAnadir = "Historico";
        sbcargahistorico("");
        btnAnadirArticulo.show();
        btnHistorico.hide();

    } else if (strEstadoAnadir == "Articulo") {
        currentrow = -1;

        sbActualizaRow();

        strEstadoAnadir = "Articulo";
        bBuscar.show();

        sbBorraGridArticulos();
        btnAnadirArticulo.hide();
        btnHistorico.show();
        txtnombrearticuloalbaran.style.backgroundColor = "white";
        txtcodigoarticuloalbaran.style.backgroundColor = "white";
        txtcodigoarticuloalbaran.value = "";
        txtnombrearticuloalbaran.value = "";
        txtnombrearticuloalbaran.placeholder = "Nombre de Articulo";
        txtcodigoarticuloalbaran.placeholder = "Familia";
        //grdarticulos.hide()
        btnAnadirArticulo.hide();
        btnHistorico.show();


        sbInicializarDatosArticulo();

        sbRefrescarImporte();
    } else {
        currentrow = -1;
        sbActualizaRow();
        grdtarifaalbaran.hide();
        // For i=0 To grdarticulos.getRowCount() -1
        sbBorraGridArticulos();
        //  Next

        //  sbInicializarDatosArticulo
        bBuscar.hide();
        btnHistorico.show();
        btnAnadirArticulo.show();
        bGuardar.show();
        bBorra.show();
        txtnombrearticuloalbaran.style.backgroundColor = "transparent";
        txtcodigoarticuloalbaran.style.backgroundColor = "transparent";
        txtnombrearticuloalbaran.placeholder = "";
        txtcodigoarticuloalbaran.placeholder = "";


        strEstadoAnadir = "Pedido";

        sbcargahistorico(" PPEDIDO<>0 ");
        btnHistorico.Visible = true;

    }
}

function sbMostrarPromo(blnVisible) {
    if (!blnVisible) {
        lblPromo1.hide();
        lblPromo2.hide();
        lblPromo3.hide();
        lblPromo4.hide();
        lblPromo5.hide();
        txtPromo.hide();
        txtPromoCV.hide();
        txtPromoUV.hide();
        txtPromoCP.hide();
        txtPromoUP.hide();
        txtPromoP.hide();
        txtPromoV.hide();
        txtPromoLotes.hide();
        bPromo.hide();
        txtPromo.value = "";
        txtPromoCV.value = "";
        txtPromoUV.value = "";
        txtPromoCP.value = "";
        txtPromoUP.value = "";
        txtPromoLotes.value = "";
        txtPromoP.value = "";

        txtPromoV.value = "";

    } else {
        txtPromoP.show();
        txtPromoV.show();
        lblPromo1.show();
        lblPromo2.show();
        lblPromo3.show();
        lblPromo4.show();
        lblPromo5.show();
        txtPromo.show();
        txtPromoP.show();
        txtPromoV.show();
        txtPromoCV.show();
        txtPromoUV.show();
        txtPromoCP.show();
        txtPromoUP.show();
        txtPromoLotes.show();
        bPromo.show();
    }



}

txtLineas.onclick = function() {
    sbMostrarPromo(true);
};

bPromo.onclick = function() {
    if (txtUnidades.value == "" || txtCajas.value == "" || txtPrecio.value == "" || txtTarifa.value == "") {
        NSB.MsgBox("Datos Incompletos");
        return;
    }
    //  If MsgBox ("Son " & txtPromoLotes.value & " lotes, con " & txtPromoUV.value * VAL(txtPromoLotes.value) &  " unidades del artículo en promoción",1)=0 Then
    if (NSB.MsgBox("Son " + txtPromoLotes.value + " lotes, con " + txtPromoUV.value * VAL(txtPromoLotes.value) + " unidades del artículo en promoción", 1) == 2) {

        return;
    }
    var misql;
    if (txtDto.value == "") {
        txtDto.value = "0";
    }
    txtUnidades.value = VAL(txtPromoLotes.value) * VAL(txtPromoUV.value);

    sbCalculaTotal();

    if (_jsCint(txtTotal.value) < 0) {
        NSB.MsgBox("No se permiten cantidades negativas. Linea de Albaran NO GUARDADA");
        return;
    }

    blnAlbaranEditado = 1;
    //bguardaalbaran.show()

    if (txtUnidades.value == "") {
        txtUnidades.value = 0;
    }
    if (txtCajas.value == "") {
        txtCajas.value = 0;
    }
    if (txtPrecio.value == "") {
        txtPrecio.value = "0";
    }




    //If arrayListaAlbaran[currentrow,12]="undefined" Or  arrayListaAlbaran[currentrow,12]="" Then

    localStorage.intPromo = VAL(localStorage.intPromo) + 1;
    //sqlList[1]="Delete from FRECUENC where   INTPROMO=" & 
    sqlList[1] = "Insert into FRECUENC (INTPROMO, IDPROMO, CODIGOARTI, PPEDIDO, PDTO, PTARIFA, PPRECIO, CODIGOCLIE, DESCRIPCIO, BULTOS, CODIGOCOMISIONISTA) ";
    sqlList[1] = sqlList[1] + " values (" + localStorage.intPromo + ", " + txtPromoCodigo.value + ", '" + arrayListaAlbaran[currentrow, 1] + "',  '" + txtTotal.value + "', '" + txtDto.value + "', '" + txtTarifa.value + "', '" + txtPrecio.value + "',  '" + txtcodigoclientealbaran.value + "', '" + arrayListaAlbaran[currentrow, 2] + "','" + arrayListaAlbaran[currentrow, 3] + "', '" + _jsCint(localStorage.comercial) + "') ";
    sqlList[2] = "Insert into FRECUENC (INTPROMO, IDPROMO, CODIGOARTI, PPEDIDO, PDTO, PTARIFA, PPRECIO, CODIGOCLIE, DESCRIPCIO,  CODIGOCOMISIONISTA)  ";
    sqlList[2] = sqlList[2] + "values (" + localStorage.intPromo + ", " + txtPromoCodigo.value + ", '" + txtPromoCP.value + "',  '" + VAL(txtPromoLotes.value) * VAL(txtPromoUP.value) + "', 0, '" + txtTarifa.value + "', 0,  '" + txtcodigoclientealbaran.value + "', '" + arrayListaAlbaran[currentrow, 2] + "', '" + _jsCint(localStorage.comercial) + "') ";



    Sql(DB, sqlList);

    sqlList = [];
    sqlList[0] = "UPDATE frecuenc SET bultos = (SELECT articulo.bultos FROM articulo WHERE frecuenc.codigoarti = articulo.codigoarti) WHERE EXISTS (SELECT * FROM articulo WHERE frecuenc.codigoarti = articulo.codigoarti  AND frecuenc.intpromo=" + localStorage.intPromo + ");";
    sqlList[0] = "UPDATE frecuenc SET descripcio = (SELECT articulo.descripcio FROM articulo WHERE frecuenc.codigoarti = articulo.codigoarti) WHERE EXISTS (SELECT * FROM articulo WHERE frecuenc.codigoarti = articulo.codigoarti  AND frecuenc.intpromo=" + localStorage.intPromo + ");";

    //  sqlList[0]=["Select id from FRECUENC where codigoarti='" & arrayListaAlbaran[currentrow,1] & "' order by ID desc limit 1;", resultrecuperarid]




    Sql(DB, sqlList);

    //Else 
    //sqlList = []
    //   sqlList[0]="Insert into FRECUENC (INTPROMO, IDPROMO, CODIGOARTI, PPEDIDO, PDTO, PTARIFA, PPRECIO, CODIGOCLIE, DESCRIPCIO, BULTOS, CODIGOCOMISIONISTA)  "
    // sqlList[0]=sqlList[1] & "values (" & intpromo & ", " & txtPromoCodigo.value & ", grdtarifaalbaran. '" & txtPromoCP  & "',  '" & val(txtPromoLotes)* val(txtPromoUP) & "', '" & txtDto.value & "', '" & txtTarifa.value & "', '" & txtPrecio.value & "',  '" & txtcodigoclientealbaran.value & "', '" & arrayListaAlbaran[currentrow,2] & "','" & arrayListaAlbaran[currentrow,3] & "', '" & CInt(localStorage.comercial) & "') "


    // misql="Update FRECUENC set PPEDIDO='" &  txtTotal.value & "',"
    // misql=misql &  " PDTO='" & txtDto.value & "', "
    // misql=misql & " PTARIFA='" & txtTarifa.value & "',"
    // misql=misql & " PPRECIO='" & txtPrecio.value & "'"
    // misql=misql & " INTPROMO='" & intpromo & "'"
    // misql=misql & " IDPROMO='" & txtPromoCodigo.value & "'"
    //' misql=misql & ", '" & txtPrecio.value & "'"
    // misql=misql & " where ID='" & arrayListaAlbaran[currentrow,12] & "';"


    // sqlList[1]=misql
    // Sql(DB,  sqlList)	

    //  arrayListaAlbaran[currentrow,10]=txtPrecio.value
    //  arrayListaAlbaran[currentrow,9]=txtDto.value
    //  arrayListaAlbaran[currentrow,0]=txtTotal.value
    //  arrayListaAlbaran[currentrow,11]=txtTarifa.value

    // grdarticulos.setValue(currentrow,0, txtTotal.value)

    // If txtTotal.value<>0 And txtPromoCodigo.value="" Then
    //  grdarticulos.cell(currentrow,0).style.background = "yellow" 
    //  ElseIf txtTotal.value<>0 And txtPromoCodigo.value>0 Then
    //  grdarticulos.cell(currentrow,0).style.background = "red" 
    //Else
    //  grdarticulos.cell(currentrow,0).style.background = "white" 
    //End If   
    //End If
    sbabrirteclado();
    bGuardar.onclick();



    sbGuardaAlbaran();
    sbRefrescarImporte();

    txtnombrearticuloalbaran.value = "";
    txtcodigoarticuloalbaran.value = "";


    NSB.MsgBox("Promoción guardada");

    sbMostrarPromo(false);
};

grdtarifaalbaran.onclick = function() {
    s = Split(event.target.id, "_");

    x = s[1];
    if (x == 0) {
        return;
    }








    if (currentrow != -1) {

        if (grdtarifaalbaran.getValue(x, 2) != null && grdtarifaalbaran.getValue(x, 2) > 0) {
            //  MsgBox  grdtarifaalbaran.getValue(x,2)
        }
        if (grdtarifaalbaran.getValue(x, 2) > 0) {
            txtPromoCodigo.value = grdtarifaalbaran.getValue(x, 2);
            sbMostrarPromo(true);
            sbCargaPromo(grdtarifaalbaran.getValue(x, 2));
        } else {
            sbMostrarPromo(false);
        }
        if (txtSerie != "55") {
            txtPrecio.value = grdtarifaalbaran.getValue(x, 1);

            txtTarifa.value = grdtarifaalbaran.getValue(x, 0);
        } else {
            txtTarifa.value = "55";
            txtPrecio.value = grdtarifaalbaran.getValue(x, 1);
        }
    } else {
        txtPromoCodigo.value = "";
    }

};

function sbCargaPromo(intCpromo) {
    sqlList = [];


    sqlList[0] = ["SELECT  * from qrypromocion  WHERE cpromo=" + intCpromo + ";", resultcargapromo];





    Sql(DB, sqlList);

}

function resultcargapromo(transaction, results) {
    var returnValue = "";
    // Called On completion of Sql command in Function btnRead_onclick



    dbrecords = results;

    //   grdarticulos.show()
    if (dbrecords.rows.length > 0) {
        if (dbrecords.rows.item(0)["CODIGOARTIVENTA"] == dbrecords.rows.item(0)["CODIGOARTIPROMO"]) {

            txtPromo.value = "PROMO: " + dbrecords.rows.item(0)["OBS"] + " : (" + dbrecords.rows.item(0)["UDSVENTA"] + " + " + dbrecords.rows.item(0)["UDSPROMO"] + ")";
        } else {
            txtPromo.value = "PROMO: " + dbrecords.rows.item(0)["OBS"];
        }
        txtPromoCV.value = dbrecords.rows.item(0)["CODIGOARTIVENTA"];
        txtPromoCP.value = dbrecords.rows.item(0)["CODIGOARTIPROMO"];
        txtPromoUV.value = dbrecords.rows.item(0)["UDSVENTA"];
        txtPromoUP.value = dbrecords.rows.item(0)["UDSPROMO"];
        txtPromoV.value = dbrecords.rows.item(0)["AVENTA"];
        txtPromoP.value = dbrecords.rows.item(0)["APROMO"];
    }
}

txtPromoLotes.onblur = function() {

    if (txtUnidades.value == "") {
        txtUnidades.value = 0;
    }
    if (txtCajas.value == "") {
        txtCajas.value = 0;
    }
    if (txtPrecio.value == "") {
        txtPrecio.value = "0";
    }


    if (txtDto.value == "") {
        txtDto.value = "0";
    }
    txtUnidades.value = VAL(txtPromoLotes.value) * VAL(txtPromoUV.value);



    blnAlbaranEditado = 1;
    //bguardaalbaran.show()


    sbCalculaTotal();
};

flipPromo.onclick = function() {
    if (flipPromo.value == "Ver Promos") {
        flipPromo.value = "Ver Todos";
    } else {
        flipPromo.value = "Ver Promos";
    }
    flipPromoonchange();
};
panelDatos.onshow = function() {
    listDatos.deleteItem("all");
    NSB.WaitCursor(false);
};

btnSalir.onclick = function() {
    nsbDOMAttr(panelDatos, 'style.display', "none");
    blnAbiertoPanel = false;
};

btnnuevoalbaran.onclick = function() {


    fnNuevoAlbaran("CA");


    // fnNuevoAlbaran()
};

listDatos.onclick = function() {
    return;
};

btnnuevoalbaran2.onclick = function() {
    fnNuevoAlbaran("55");
};

btnnuevoalbaran1.onclick = function() {
    fnNuevoAlbaran("01");
};

btnEditarlbaran.onclick = function() {
    sbeditaralbaran();
};

btnCobros.onclick = function() {
    sbAbrirCobrosCliente();
};
var myData, myStore, myOnItemDisclosure, mySelModel, groupingBase, sendingObject;
var blnAbiertoPanel;
var strTarifaClienteActual;
var blnResumenCobros;
var blnNuevoAlbaran;
var strComercial;
var strEstadoAnadir;
var filtrotarifa;
var tipoalbaran;

var filtroCA = " CODIGOARTI LIKE 'C%' AND ";
var filtro55 = " (CODIGOARTI in (select CODIGOARTI FROM ATARIFAS WHERE CODIGOTARI=55)) and "; //LIKE '26%' or CODIGOARTI LIKE '40%') and "
var filtro01 = " (CODIGOARTI not LIKE '26%' or CODIGOARTI LIKE '40%') and ";
var mysql;

function Main() {
    document.body.style.backgroundColor = "lightgray";

    blnAbiertoPanel = false;
    // Ext.setup({onReady: makeApplication})

    if (localStorage.comercial != null && localStorage.comercial != "0") {
        TextBox1.value = "V.2.5 C." + localStorage.comercial;
    } else {
        TextBox1.value = "V.2.5 SIN Comercial ";
    }

    if (localStorage.intPromo != null && localStorage.intPromo != "0") {

    } else {
        localStorage.intPromo = 1;
    }
    if (VAL(localStorage.intPromo) > 1000) {
        localStorage.intPromo = 1;
    }


    if (localStorage.intUltimoAlbaran != null && localStorage.intUltimoAlbaran != "0") {

    } else {
        localStorage.intUltimoAlbaran = 0;
    }

    if (localStorage.intUltimoenvio != null && localStorage.intUltimoenvio != "0") {

    } else {

        localStorage.intUltimoenvio = _jsCint(Rnd(99) * 100);
    }

    if (Len(localStorage.intUltimoenvio) > 2) {
        localStorage.intUltimoenvio = _jsCint(Rnd(99) * 100);
    }
    // MsgBox  localStorage.intUltimoenvio 


    strEstadoPrincipal = "Clientes";
    DB = SqlOpenDatabase("database.db", "1.0", "BaseKodeka");

    misql = "Update FRECUENC set PPEDIDO=0,";
    misql = misql + " PDTO=0, ";
    misql = misql + " PTARIFA=0, ";
    misql = misql + " PPRECIO=0";
    sqlList = [];
    sqlList[0] = misql;
    Sql(DB, sqlList);
}


function fnRecuperarElementoLista(objLista, idElemento, idColumna) {
    var returnValue = "";
    if (TypeName(idElemento) == "object") {
        return returnValue;
    }
    returnValue = objLista.children[1].children[0].children[idElemento].childNodes[0].children[idColumna].textContent;
    return returnValue;
}